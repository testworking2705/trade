<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UploadData extends MY_Controller {

	public function __construct($value='')
	{
		parent::__construct();
		//echo BASEPATH."<br>" ;
		//echo APPPATH."<br>" ;
		//exit();		// $this->load->model('AuthModel', 'am');
		//$this->load->model("math_model");	
	}

	public function index()
	{	// && $this->checkRoleLoginUser($this->session->admin->role_id)
		if($this->checkAdminLogin() != true )
			redirect('login');

		$data['title'] = "Contract" ;
		$data['pageheader'] = "Contracts List" ;
		$data['contracts'] = $this->contract->getContracts() ;
		
		$this->load->view('pages/trades/index', $data);
		
	}



	private function uploadExcel($file='')
	{
		//print_r($file);exit();
		require_once(APPPATH.'libraries/phpexcel/vendor/php-excel-reader/excel_reader2.php');
		require_once(APPPATH.'libraries/phpexcel/vendor/SpreadsheetReader.php');

		$allowedFileType = ['application/vnd.ms-excel','text/xls','text/xlsx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];
  		$success = 0;
  		$fail = 0 ;
  		$data =[]; 
		if(in_array($file['tradefile']["type"],$allowedFileType)){

		    $targetPath = 'uploads/'.$file['tradefile']['name'];
		    move_uploaded_file($file['tradefile']['tmp_name'], $targetPath);
		    
		    $Reader = new SpreadsheetReader($targetPath);
		    
		    $sheetCount = count($Reader->sheets());
		    // for($i=0; $i<$sheetCount; $i++){
		    for($i=0; $i<1; $i++){
		    	$Reader->ChangeSheet($i);
		        foreach ($Reader as $key => $Row) {
		      		if($Row['0'] == '' || empty($Row['0']) )
		      			break;
		      		else
			      		array_push($data, $Row);	
		        }
		        return $data;
		    }
		    
		}
		    
		else
		{ 
			return print_r( array("error" => true, "message" => "Invalid File Type. Upload Excel File") ) ;
		    /*$type = "error";
		    $message = "Invalid File Type. Upload Excel File.";*/
		}
		 
	}
	 
	
		



	public function fileupload($value='')
	{
		if($this->checkAdminLogin() != true)
			redirect('login');

		$data['title'] = 'Trades Upload' ;
		$data['form_title'] = 'Upload Trades Wise' ;
		$data['trades'] = $this->admin->trades();

		$trade =[];
		$check_column = false;

		$n_i = $c_i =$curr_i = $fcm_i = $price_i =$ls_i = $qty_i = $date_i = 0 ;

		if(!empty($this->input->post('trades')) && $this->input->post('tradeId') > 0 ){
			if($_FILES['tradefile']['name'] == "" && $_FILES['tradefile']['error'] == "4"){
				print_r(json_encode(array("error" => true, "message"=> "Invalid File Type. Upload Excel/Csv File")));exit();	
			}			  
			$id = $this->input->post('tradeId') ;
			$data = $this->uploadExcel($_FILES);
		 	$colum_list = $this->upload->columnsMaster($id);
		 	//print_r($data);exit();
			if($this->input->post('trades') == 'IC'){		// ci trades 
				foreach ($data as $key => $val) {
					if($key == '0'){
						// Foreach Loop For Check Column in excwl match With Column Master  
						foreach ($colum_list as $kl => $vl)	{
					 		foreach ($data as $keys => $vals) {
					 			if($keys == '0'){
					 				foreach ($vals as $k => $v) {
					 					if($vl->column_name == $v){
					 						if($vl->names =='name'){$n_i=$k;}
											else if($vl->names =='contract'){$c_i=$k;}
											else if($vl->names =='currency'){$curr_i=$k;}
											else if($vl->names =='fcm'){$fcm_i=$k;}
											else if($vl->names =='price'){$price_i=$k;}
											else if($vl->names =='ls'){$ls_i=$k;}
											else if($vl->names =='qty'){$qty_i=$k;}
											else if($vl->names =='date'){$date_i=$k;}
					 					}
					 				}
					 			}
					 		}
						}
						//	!! Foreach Loop For Check Column in excwl match With Column Master
					}
					else{
						$price = $val[$price_i] ;
						$quantity = $val[$qty_i] ;

						if(!is_float($price) && !is_int($price)) {
							print_r(json_encode(array("error" => true, "message"=> "InVaild price at row no ". $key .' and value is '.$price )));exit();
						}

						if(!is_float($quantity) && !is_int($quantity) ) {
							 
							print_r(json_encode(array("error" => true, "message"=> "InVaild quantity row no ". $key .' and value is '.$quantity )));exit();
						}
						$bl = (strcasecmp(trim($val['11']) ,'long')==0) ? 'B' : 'S' ;

						$trade[$key]['name'] 		= 	$this->check_input($val[$n_i]) ;		
						$trade[$key]['contract'] 	= 	$this->check_input($val[$c_i]) ;		
						$trade[$key]['currency'] 	=	$this->check_input($val[$curr_i]) ; 		
						$trade[$key]['price'] 	 	= 	$this->check_input($val[$price_i]) ;	
						$trade[$key]['long_short'] 	=  	$bl;	
						$trade[$key]['qunatity'] 	= 	$this->check_input($val[$qty_i]) ;		
						$trade[$key]['datetime'] 	= 	$this->changeDateByFormat($this->check_input($val[$date_i])) ;		
						$trade[$key]['fcm'] 		= 	$this->check_input($val[$fcm_i]) ;	
						$trade[$key]['trade_id'] 	=	$id ;		
						$trade[$key]['client_id'] 	= 	1 ;		
						$trade[$key]['user_id'] 	= 	$this->session->admin->id ; ;	
						
					}
				}
				$trade = array_reverse($trade,TRUE);
				$this->db->insert_batch('data_table', $trade);
				print_r(json_encode(array("error" => false, "message"=> "Success. IC Trade Upload")));exit();
			}
			else if($this->input->post('trades') =='QT'){	// qt trades 
				//print_r($colum_list);
				foreach ($data as $key => $val) { 
					if($key == '0'){
						// Foreach Loop For Check Column in excwl match With Column Master  
						foreach ($colum_list as $kl => $vl)	{
					 		foreach ($data as $keys => $vals) {
					 			if($keys == '0'){
					 				foreach ($vals as $k => $v) {
					 					if($vl->column_name == $v){
					 						if($vl->names =='name'){$n_i=$k;}
											else if($vl->names =='contract'){$c_i=$k;}
											else if($vl->names =='currency'){$curr_i=$k;}
											else if($vl->names =='fcm'){$fcm_i=$k;}
											else if($vl->names =='price'){$price_i=$k;}
											else if($vl->names =='ls'){$ls_i=$k;}
											else if($vl->names =='qty'){$qty_i=$k;}
											else if($vl->names =='date'){$date_i=$k;}
					 					}
					 				}
					 			}
					 		}
						}
						
						//	!! Foreach Loop For Check Column in excwl match With Column Master
					}
					else{
						$price = $val[$price_i] ;
						$quantity = $val[$qty_i] ;

						if(!is_float($price) && !is_int($price)) {
							print_r(json_encode(array("error" => true, "message"=> "InVaild price at row no ". $key .' and value is '.$price )));exit();
						}

						if(!is_float($quantity) && !is_int($quantity) ) {
							print_r(json_encode(array("error" => true, "message"=> "InVaild quantity row no ". $key .' and value is '.$quantity )));exit();
						}
							 
							
						$ls = (strcasecmp(trim($val[$ls_i]) ,'long')==0) ? 'B' : 'S' ;
						
						$trade[$key]['name'] 			= $this->check_input($val[$n_i]) ;		
						$trade[$key]['contract'] 		= $this->check_input($val[$c_i]) ;		
						$trade[$key]['currency'] 		= $this->check_input($val[$curr_i]) ; 		
						$trade[$key]['price'] 			= $this->check_input($val[$price_i]) ;	// check Where Price Float or Int
						$trade[$key]['long_short'] 		= $ls ;			
						$trade[$key]['qunatity'] 		= $this->check_input($val[$qty_i]) ;		// check Where quantity Float or Int	
						$trade[$key]['datetime'] 		= $this->changeDateByFormat($this->check_input($val[$date_i]));		
						$trade[$key]['fcm'] 			= $this->check_input($val[$fcm_i]) ;	
						$trade[$key]['trade_id'] 		= $id ;		
						$trade[$key]['client_id'] 		= 1 ;		
						$trade[$key]['user_id'] 		= $this->session->admin->id ; ;		

						//break;
					}


				}
				
				//print_r($trade);
				$trade = array_reverse($trade,TRUE);
				$this->db->insert_batch('data_table', $trade);
				print_r(json_encode(array("error" => false, "message"=> "Success. QT Trade Upload")));exit();
			}
			else if($this->input->post('trades') =='TT'){	// tt trades 
				foreach ($data as $key => $val) {
					if($key == '0'){
						// Foreach Loop For Check Column in excwl match With Column Master  
						foreach ($colum_list as $kl => $vl)	{
					 		foreach ($data as $keys => $vals) {
					 			if($keys == '0'){
					 				foreach ($vals as $k => $v) {
					 					if($vl->column_name == $v){
					 						if($vl->names =='name'){$n_i=$k;}
											else if($vl->names =='contract'){$c_i=$k;}
											else if($vl->names =='currency'){$curr_i=$k;}
											else if($vl->names =='fcm'){$fcm_i=$k;}
											else if($vl->names =='price'){$price_i=$k;}
											else if($vl->names =='ls'){$ls_i=$k;}
											else if($vl->names =='qty'){$qty_i=$k;}
											else if($vl->names =='date'){$date_i=$k;}
					 					}
					 				}
					 			}
					 		}
						}
						//	!! Foreach Loop For Check Column in excwl match With Column Master
					}
					else{
						$price = $val[$price_i] ;
						$quantity = $val[$qty_i] ;

						if(!is_float($price) && !is_int($price)) {
							print_r(json_encode(array("error" => true, "message"=> "InVaild price at row no ". $key .' and value is '.$price )));exit();
						}

						if(!is_float($quantity) && !is_int($quantity) ) {
							 
							print_r(json_encode(array("error" => true, "message"=> "InVaild quantity row no ". $key .' and value is '.$quantity )));exit();
						}

						$bl = (strcasecmp(trim($val[$ls_i]) ,'long')==0) ? 'B' : 'S' ;
					 
						$trade[$key]['name'] 		= 	$this->check_input($val[$n_i]) ;		
						$trade[$key]['contract'] 	= 	$this->check_input($val[$c_i]) ;		
						$trade[$key]['currency'] 	=	$this->check_input($val[$curr_i]) ; 		
						$trade[$key]['price']	 	= 	$this->check_input($val[$price_i]) ;	
						$trade[$key]['long_short'] 	= 	$bl ;			
						$trade[$key]['qunatity'] 	= 	$this->check_input($val[$qty_i]) ;		
						$trade[$key]['datetime'] 	= 	$this->changeDateByFormat($this->check_input($val[$date_i]));		
						$trade[$key]['fcm'] 		= 	$this->check_input($val[$fcm_i]) ;	
						$trade[$key]['trade_id'] 	=	$id ;		
						$trade[$key]['client_id'] 	= 	1 ;		
						$trade[$key]['user_id'] 	= 	$this->session->admin->id ; ;		

						//break;
					}
				}
				$trade = array_reverse($trade,TRUE);
				$this->db->insert_batch('data_table', $trade);
				print_r(json_encode(array("error" => false, "message"=> " TT Trade Upload Successfully")));exit();
			}
			else if($this->input->post('trades') =='MN'){	// manual trades 

				foreach ($data as $key => $val) {
					if($key == '0'){
						// Foreach Loop For Check Column in excwl match With Column Master  
						foreach ($colum_list as $kl => $vl)	{
					 		foreach ($data as $keys => $vals) {
					 			if($keys == '0'){
					 				foreach ($vals as $k => $v) {
					 					if($vl->column_name == $v){
					 						if($vl->names =='name'){$n_i=$k;}
											else if($vl->names =='contract'){$c_i=$k;}
											else if($vl->names =='currency'){$curr_i=$k;}
											else if($vl->names =='fcm'){$fcm_i=$k;}
											else if($vl->names =='price'){$price_i=$k;}
											else if($vl->names =='ls'){$ls_i=$k;}
											else if($vl->names =='qty'){$qty_i=$k;}
											else if($vl->names =='date'){$date_i=$k;}
					 					}
					 				}
					 			}
					 		}
						}
						//	!! Foreach Loop For Check Column in excwl match With Column Master
					}
					else{
						$price = $val[$price_i] ;
						$quantity = $val[$qty_i] ;
						if(!is_float($price) && !is_int($price)) {
							print_r(json_encode(array("error" => true, "message"=> "InVaild price at row no ". $key .' and value is '.$price )));exit();
						}

						if(!is_float($quantity) && !is_int($quantity) ) {
							 
							print_r(json_encode(array("error" => true, "message"=> "InVaild quantity row no ". $key .' and value is '.$quantity )));exit();
						}

						$bl = (strcasecmp(trim($val['4']) ,'long')==0) ? 'B' : 'S' ;

						
						$trade[$key]['name'] 		= 	$this->check_input($val[$n_i]) ;		
						$trade[$key]['contract'] 	= 	$this->check_input($val[$c_i]) ;		
						$trade[$key]['currency'] 	=	$this->check_input($val[$curr_i]) ; 		
						$trade[$key]['price'] 		= 	$this->check_input($val[$price_i]) ;	
						$trade[$key]['long_short'] 	= 	$bl;			
						$trade[$key]['qunatity'] 	= 	$this->check_input($val[$qty_i]) ;		
						$trade[$key]['datetime'] 	= 	$this->changeDateByFormat($this->check_input($val[$date_i]));		
						$trade[$key]['fcm'] 		= 	$this->check_input($val[$fcm_i]) ;	
						$trade[$key]['trade_id'] 	= 	$id ;		
						$trade[$key]['client_id'] 	= 	1 ;		
						$trade[$key]['user_id'] 	= 	$this->session->admin->id ;		

						//break;
					}
				}
				$trade = array_reverse($trade,TRUE);
				$this->db->insert_batch('data_table', $trade);
				print_r(json_encode(array("error" => false, "message"=> " Manual Trade Upload Successfully")));exit();
			}
			//$this->load->view('pages/trades/tradeupload', $data);
		}
		else{

			$this->load->view('pages/trades/tradeupload', $data);
		}
	}

	
	public function closingPrice($value='')
	{
		if($this->checkAdminLogin() != true)
			redirect('login');

		$trade =[];
		$data['title'] = "Closing" ;
		$data['pageheader'] = "Closing Price" ;
		if(isset($_FILES['tradefile']['name'])){
			if($_FILES['tradefile']['name'] == "" && $_FILES['tradefile']['error'] == "4"){
				print_r(json_encode(array("error" => true, "message"=> "Invalid File Type. Upload Excel/Csv File")));exit();	
			}

			$data = $this->uploadExcel($_FILES);
			if(count($data) > 1 ){
				foreach ($data as $key => $val) {
					if($key == '0'){
						
					}
					else{

						$trade[$key]['contract'] = $this->check_input($val['1']) ;		
						$trade[$key]['price'] = 	$this->check_input($val['2']) ;	
						$trade[$key]['currency'] =	$this->check_input($val['3']) ; 		
						$trade[$key]['close_date'] = $this->check_input($this->changeDateFormat($val['4'])) ;		
						$trade[$key]['user_id'] = $this->session->admin->id ; ;	
					}
				}

			}
			$this->db->insert_batch('closing_price', $trade);
			print_r(json_encode(array('error'=> false, 'data' => $data, "message" => 'closing price uploeded' )));exit();	
		}
			


		$this->load->view('pages/trades/closeprice', $data);
	}
	 
}





/*	*****************************************
INSERT COLUMN NAME IN COLUMN MASTER	
*******************************************/
/*
for ($i=0; $i <count($Row) ; $i++) { 			        				        	
$c_name = $this->check_input($Row[$i]);
$query = "insert into trades_columns_master(column_name,trade_id) values('".$c_name."','1')";
$result = $this->db->query($query);
}*/


/*
/*$name = "";
		            if(isset($Row[0])) {
		                // $name = mysqli_real_escape_string($conn,$Row[0]);
		                $name = $Row[0];
		            }
		            
		            $description = "";
		            if(isset($Row[1])) {
		                // $description = mysqli_real_escape_string($conn,$Row[1]);
		                $description = $Row[1];
		            }*/
		            
		            /*if (!empty($name) || !empty($description)) {

		                $query = "insert into tbl_info(name,description) values('".$name."','".$description."')";
		                $result = $this->db->query($query);
		            
		                if (! empty($result)) {
		                    $success++ ;
		                    //return print_r( array("error" => false, "message" => "Excel Data Imported into the Database") ) ;

		                } else {
		                    $fail++ ;
		                    //return print_r( array("error" => true, "message" => "Problem in Importing Excel Data") ) ;
		                }
		            }*/
