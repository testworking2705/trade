<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Client extends MY_Controller {

	public function __construct($value='')
	{
		parent::__construct();
		//print_r($this->session);
		// $this->load->model('AuthModel', 'am');
		//$this->load->model("math_model");	

	}
	 
	public function index()
	{
		if($this->checkAdminLogin() != true)
			redirect('login');

		$data['title'] = "Client" ;
		$data['pageheader'] = "Client list" ;
		$data['clients'] = $this->client->getClients() ;
		//$data['companies'] = $this->client->getClients() ;
		//$data['contracts'] = $this->client->getClients() ;
		//$data['report'] = $this->client->getClients() ;

		
		$this->load->view('pages/admin/client/index', $data);
	}

	public function create($value='')
	{
		if($this->checkAdminLogin() != true)
			redirect('login');

		$data['title'] = "Client" ;
		$data['pageheader'] = "Add Client" ;
		 
		 
		if($this->form_validation->run('client')== true){

			$clientArray = array(
    		'client_id' => $this->input->post('client_id'),
    		'first_name' 		=> $this->input->post('first_name'),
    		'last_name' 	=> $this->input->post('last_name'),
    		'company_associated_with' => $this->input->post('company_associate'),
    		'cid' 		=> $this->input->post('c_id'),
    		'subscription' 	=> $this->input->post('subscription'),
    		'market_data' 		=> $this->input->post('market_data'),
    		'admin_fee' 		=> $this->input->post('admin_fee'),
    		'others1' 		=> $this->input->post('others'),
    		'commission' 		=> $this->input->post('commision'),
    		'clearing_fee' 		=> $this->input->post('clearingfee'),
    		'exchange_fee' 		=> $this->input->post('exchangefee'),
    		'tradetinal' 		=> $this->input->post('transationalfee'),
    		'nfa' 		=> $this->input->post('nfa'),
    		'others2' 		=> $this->input->post('pertrade_other'),
    		'address' 		=> $this->input->post('address'),
    		'email' 		=> $this->input->post('email'),
    		'mobile' 		=> $this->input->post('mobile')
    	);
        	 
        		
      		$result = $this->client->create($clientArray) ;
      		if($result){
      			$this->session->set_flashdata('success','Client Created Successfully. ');
      			redirect('client-add');
      		}
      		else{
      			$this->session->set_flashdata('fail','Client Create fail. ');
      			redirect('client-add');

      		}

			$this->load->view('pages/admin/client/create', $data);
		}
		$this->load->view('pages/admin/client/create', $data);
	}


	public function edit()
	{
		if($this->checkAdminLogin() != true)
			redirect('login');

		$data['title'] = "Client" ;
		$data['pageheader'] = "Client Update" ;
		$id = $this->uri->segment(2,0) ;
		$data['id'] = $id;
		$data['clients'] = $this->client->getClientById($id);

		if($this->form_validation->run('client')== true){

			$clientArray = array(
    		'client_id' => $this->input->post('client_id'),
    		'first_name' 		=> $this->input->post('first_name'),
    		'last_name' 	=> $this->input->post('last_name'),
    		'company_associated_with' => $this->input->post('company_associate'),
    		'cid' 		=> $this->input->post('c_id'),
    		'subscription' 	=> $this->input->post('subscription'),
    		'market_data' 		=> $this->input->post('market_data'),
    		'admin_fee' 		=> $this->input->post('admin_fee'),
    		'others1' 		=> $this->input->post('others'),
    		'commission' 		=> $this->input->post('commision'),
    		'clearing_fee' 		=> $this->input->post('clearingfee'),
    		'exchange_fee' 		=> $this->input->post('exchangefee'),
    		'tradetinal' 		=> $this->input->post('transationalfee'),
    		'nfa' 		=> $this->input->post('nfa'),
    		'others2' 		=> $this->input->post('pertrade_other'),
    		'address' 		=> $this->input->post('address'),
    		'email' 		=> $this->input->post('email'),
    		'mobile' 		=> $this->input->post('mobile')
    	);
        	 
        		
      		$result = $this->client->update($clientArray, $id) ;
      		if($result){
      			$this->session->set_flashdata('success','Client Update Successfully. ');
      			redirect('client-edit/'.$id);
      		}
      		else{
      			$this->session->set_flashdata('fail','Client Update fail. ');
      			redirect('client-edit/'.$id);

      		}

			$this->load->view('pages/admin/client/edit', $data);
		}

		$this->load->view('pages/admin/client/edit', $data);
	}


	 
}
