<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class OutCome extends MY_Controller {
	
	// Following cost are per trade costs
	//private $brokerageRate ;
	private $commissionFee  ;
	private $exchangeFee ;
	private $clearingFee ;
	private $transactionalFee ;
	private $nfaFee ;

	// Fixed Cost 
	private $subscription ;
	private $market_data ;
	private $admin_fee ;
	private $others1 ;

	private $tickSize = '0.025' ;
	private $tickValue = '10' ;
	private $begining_balance = '0' ;
	private $closing_balance = '0' ;
	private $net_equity = '0' ;

	private $response =[];
	private $holdContract =[];
	//private $hold_array =[];

	public function __construct($value='')
	{
		parent::__construct();
		// $this->load->model('AuthModel', 'am');
		//$this->load->model("math_model");
		$this->subscription = 40;	
		$this->market_data 	= 110;	
		$this->admin_fee 	= 100;	

		//echo $this->getClosingPriceOfContract('F.US.GLEV20', '04-02-2020');
	}

	public function setInitialRatesPerTrades($client_id)
	{
		$client_info = $this->client->getClients($client_id);
		//$this->brokerageRate 	= $client_info['0']->commission ;
		$this->commissionFee 	= $client_info['0']->commission ;
		$this->exchangeFee 		= $client_info['0']->exchange_fee ;
		$this->clearingFee 		= $client_info['0']->clearing_fee ;
		$this->transactionalFee = $client_info['0']->tradetinal ; 
		$this->nfaFee 			= $client_info['0']->nfa; 
		$this->begining_balance = $client_info['0']->balance; 
		$this->net_equity 		= $client_info['0']->net_equity; 
		//$this->brokerage 		= $client_info['0']->brokerage 
			
	}

	
	 
	public function index()
	{
		if($this->checkAdminLogin() != true)
			redirect('login');

		$data['title'] = "Out Come" ;
		$data['pageheader'] = "Out Come" ;
		// $data['contracts'] = $this->contract->getContracts() ;

		$this->load->view('pages/admin/outcome', $data);
	}

	private function brokerage_cal($sumofqty='')
	{	
		//echo "BRO ".$this->commissionFee."<br>";
		return  ($sumofqty) * $this->commissionFee ;   
	}
	private function transactional_cal($sumofqty='')
	{
		//echo "TRA ".$this->transactionalFee."<br>";
		return  ($sumofqty) * $this->transactionalFee ;
	}
	private function exchange_cal($sumofqty='')
	{
		//echo "EXC ".$this->exchangeFee."<br>";
		return  ($sumofqty) * $this->exchangeFee ;
	}
	private function clearing_cal($sumofqty='')
	{
		//echo "CLE ".$this->clearingFee."<br>";
		return  ($sumofqty) * $this->clearingFee ;
	}
	private function nfa_cal($sumofqty='')
	{
		//echo "NFA ".$this->commissionFee."<br>";
		return  ($sumofqty) * $this->nfaFee ;
	}

	private function getCodeFromContract($value='')
	{
		$str = trim($value);	
		//$str = substr(explode("|", $str)[0], 0,-2);   // F.US.GLEV20_S|F.US.GLEV20_B
		// $str = substr($str, 0,-2);   //F.US.GLEM20
		if("F.US." == substr($str, 0,5)){
			return substr(substr($str, 5), 0,-3) ;
		}	
		else{
			return explode(" ", $str)[0];
		}
	}

	private function getTickFromContractCode($code='')
	{
		 
		$tick = [];
		if(!empty($code)){

			$query = $this->db->select('tick_size, tick_value')->get_where('contract_mst', array('code' =>trim($code) ));
			//echo $this->db->last_query();
				$result = $query->row();
				//print_r($result); 
				$tick['tick_size'] = $result->tick_size;
				$tick['tick_value'] = $result->tick_value;
		}
		else{
			$tick['tick_size'] = '0.025';
			$tick['tick_value'] = '10';
		}
		return $tick ;
	}


	/*public function getUniqueDate()
	{
		foreach (array_reverse($this->client->getNewDateList($from, $to, 'datetime'), true) as $key => $value) {
			echo "DATE: " . $value->datetime ."<br>";
		}
	}*/

	private function createHoldingArray($array)
	{
		/*print_r(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>><br>");
		print_r($array);
		print_r(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>><br>");*/

			
		$hold_array =[];
		$cond = false ;
		//print_r("COUNT ". count($array). "<br>");
		$loopcount = 0;
		for ($i=0; $i < count($array) ; $i++) {
			$k = count($hold_array) ;
			if(count($hold_array)>0){
				$k = count($hold_array) ;
				for ($j=0; $j < count($hold_array) ; $j++) { 					
					if($array[$i]['id'] == $hold_array[$j]['id']){
						$hold_array[$j]['qty'] +=  1 ;  
						$cond = false ;
						break ;
					}
					else{
						$cond = true ;
					}
					//print_r("INNER CLOSE ARRAY INDEX ID========================= $j  ". count($hold_array). "<br>");
				}
				if($cond){
					 
					$hold_array[$k] =$array[$i];
					$hold_array[$k]['qty'] =  1;	
				}
				//print_r($hold_array);
			}
			else{

				$hold_array[$k] = $array[$i];				
				$hold_array[$k]['qty'] =  1;
			}
			//print_r($hold_array);
		}
		//print_r($hold_array);
		return $hold_array ;
		
	}

	private function holdingDateWise($date, $contract, $client, $fcm)
	{	
		$arr = array('client_id' => $client, 'contract' => $contract, 'fcm' =>$fcm, 'hold_status' => '1' );
		$this->db->select('id, client_id as name, long_short, contract, price as total_price, quantity as qty, fcm, work_status, datetime');
		$query = $this->db->get_where('hold_contract', $arr);
		//echo $this->db->last_query()."<br>";
		if($query->num_rows() > 0){
			$this->db->where('client_id', $client);
			$this->db->where('contract' , $contract);
			$this->db->where('fcm' , $fcm);
			$this->db->update('hold_contract', array('hold_status' => 0));
			 //echo $this->db->last_query()."<br>";
			return $query->result_array();
		}
		else{
			return array();
		}
		 
	}


	private function getClosingPriceOfContract($contract, $date)
	{
		try{
			$arr  = array('close_date'=>  $date, 'contract' => $contract );
			$query = $this->db->get_where('closing_price', $arr);
			echo $this->db->last_query();
			return $query->row()->price;

		}catch(Exception $e ){
			echo json_encode(array('error' => true, 'message' => 'Exception Throw '. $e->getMessage()));exit();	
		}
	}
		
			

	private function previouDayRecordClientWise($client_id)
	{
		$arr = array('client_id' => $client_id);
		$query = $this->db->get_where('daily_client_wise_trxn', $arr);
		if($query->num_rows() > 0)
			return $query->row();
		else
			return array();
	}

	private function checkCloseingPriceList($from, $to)
	{
		
		$contractArray = $this->mm->contractListDateWise($from, $to);
		//print_r(json_encode($contractArray));
		if($contractArray == false ){
			echo json_encode(array('error' => true, 'message' => 'No trade found in date Range.'));exit();	
		}
		return true;
		//echo json_encode(array('error' => true, 'message' => 'No trade found in date Range 1111.'));exit();

		
	}



	// Calculate Gross Profit Loss 
	public function calculate_gpl($value='')
	{

		if($this->checkAdminLogin() != true)
			redirect('login');

		/*$from 	='02-10-20';
		$to 	='02-10-20';*/

		$finalshowArray =[];
		$finalholdArray =[];

		$from 	=	$this->input->post('from');
		$to 	=	$this->input->post('to');
		if(empty($from)){
			echo json_encode(array('error' => true, 'message' => 'Please Select From Date'));exit();	
		}	
		if(empty($to)){	
			echo json_encode(array('error' => true, 'message' => 'Please Select To Date'));exit();
		}
		if ($to < $from){
			echo json_encode(array('error' => true, "message" => "Please Select Future Date in to "));exit();
		}
		
		$from 	= date('Y-m-d', strtotime($from));
		$to 	= date('Y-m-d', strtotime($to));	

		/****************************************/
		//Check Closeing Price For all New Updated Contracts
		if($this->checkCloseingPriceList($from, $to) == false){
			echo json_encode(array('error' => true, 'message' => 'Please Select To Datddddse'));exit();		
		}
		//echo json_encode(array('error' => true, 'message' => 'STOP EXECUTION 2'));exit();


		//exit();
		/*!!***************************************!!*/

		//
		//echo json_encode(array('error' => true, 'message' => 'Please Select To Datddddse'));exit();

		/************************************************************
		Get Date list in Range of From and To 
		*************************************************************/
		//$date_arr = array_reverse($this->client->getNewDateList($from, $to, 'datetime'), true);
		$date_arr = $this->client->getNewDateList($from, $to, 'datetime');
		
		//echo json_encode($date_arr);exit();
		// echo json_encode(array('error' => true, 'data' => $from.' '.$to,  "message" => "Test data from exit "));exit();
		if(count($date_arr) == 0){
			echo json_encode(array('error' => true, 'message' => 'No Record Foound')); exit();
		}
		//echo '<pre>';
		foreach ($date_arr as $key => $date) {
			$broker = $this->client->getNewDateList($date->datetime, $date->datetime, 'fcm');
			if(count($broker) > 0){
				foreach ($broker as $cmpk => $cmpv) {		// broker Arr list of above data between to range 
					
					$client_list = $this->client->getNewDateList($date->datetime, $date->datetime, 'name', $cmpv->fcm);
					//print_r($client_list); exit(); 
					$successCount = 0 ;
					$failCount = 0 ;
					if(count($client_list) > 0){
						foreach ($client_list as $clik => $cliv) {
							

							/*************************************************************
							// get client master data as client wise
							**************************************************************/
							$this->setInitialRatesPerTrades('ACT01');
							$contracts = $this->client->getNewDateList($date->datetime, $date->datetime, 'contract', $cmpv->fcm);
							// print_r( $contracts); 
							/* Contract Wise Loop */
							$ending_balance = 0;
							$client_day_calculation = [] ;
							$open_trade_equity =	$final_comm =$final_clear =$final_exe =$final_nfa= $final_trxn = $final_gpl = $final_npl = 0 ;
							$final_fee = 0 ;
							

							foreach ($contracts as $key => $val) {
								//print_r($val->contract);
								$code = $this->getCodeFromContract(trim($val->contract));
								$tick = $this->getTickFromContractCode($code);
								$tick_data =  $tick['tick_value'].'_'.$tick['tick_size'] ;

								$this->holdContract = $this->holdingDateWise($date->datetime, $val->contract, $cliv->name, $cmpv->fcm);
								
								$rcord = $this->getTradeRecordsCalculation(trim($cliv->name), trim($date->datetime), trim($val->contract) );
								
								/************************************************************************
								Update Data table for Record that we are getting in selected range.
								*************************************************************************/
								$this->contract->updateContarctStatus($cliv->name, $date->datetime, $val->contract, $cmpv->fcm);


								$holdContractArr = $rcord['holding'] ;
								$caluContractArr = $this->createHoldingArray($rcord['calcu']) ;
								$orgContractArr  = $rcord['org'] ;
								//print_r($caluContractArr);
								 /**************************************************************
								 get Holding array 
								 ***************************************************************/
								 // print_r($caluContractArr);


								$contract = $this->getUniqueArrayColumnWiseFromArray($caluContractArr, 'pname');
								
								/*****************************************************
								Calculate Brokrage And all other factor 
								******************************************************/
								$total_fee = 0;
								$totalgpl = 0;
								$totalqty = 0;
								$close_count = 0;
								$dt = 0 ; 
								$factor = [];
								$difgpl = [];
								$difgplcont = [];
								
								foreach ($contract as $key => $value) {
									$total = $total_fee  = $totalqty = $tick_data = $bro = $tra  = $exc  = $cle  = $nfa  = 0 ;
									
									/*************
									Calculate Quantity when have open positions 
									**************/	
									if(count($this->holdContract) > 0 ){
										for ($hk=0; $hk < count($orgContractArr) ; $hk++) {
											$qty = $orgContractArr[$hk]['qty'];
											$totalqty += $qty ;
										}
									} 
									

									for ($k=0; $k < count($caluContractArr) ; $k++) { 
										if(count($this->holdContract) > 0 ){
											// In case Of holding all factor are caulculate in above case. 
										}
										else{
											/*************
											Calculate Quantity when No open positions 
											**************/
											if(trim($value) == trim($caluContractArr[$k]['pname'])){
												$qty = ($caluContractArr[$k]['open_close_hold'] =='close' ?  $caluContractArr[$k]['qty'] * 2 : $caluContractArr[$k]['qty'] );
												$totalqty += $qty ;
											}
										}
										

										if($caluContractArr[$k]['open_close_hold'] == 'close' ){
											$close_count += $caluContractArr[$k]['qty'] ;
											
											$dt += $caluContractArr[$k]['diff']*$caluContractArr[$k]['qty'] ;
											
										}
										
									}
									//$final_comm =$final_clear =$final_exe =$final_nfa= $final_trxn = $final_fee = $final_gpl = $final_npl = 0 ;

									$bro  	= $this->brokerage_cal($totalqty) ;
									$cle 	= $this->clearing_cal($totalqty);
									$exc 	= $this->exchange_cal($totalqty) ;	
									$tra  	= $this->transactional_cal($totalqty) ;	
									$nfa 	= $this->nfa_cal($totalqty);

									$final_comm +=$bro;
									$final_clear +=$cle;
									$final_exe +=$exc;
									$final_nfa +=$nfa;
									$final_trxn +=$tra;

									$total_fee += $cle+$exc+$tra+$nfa ;
									

									$gpl = round(($tick['tick_value'] * ( $dt/ $tick['tick_size'])), 2);
									$npl = round(($tick['tick_value'] * ( $dt/ $tick['tick_size'])), 2) - $total_fee ; 
									
									$final_gpl += $gpl ; 
									//

									$factor[$value]['contract'] = $val->contract;
									$factor[$value]['client_id'] = trim($cliv->name);
									$factor[$value]['qty'] = $totalqty;
									$factor[$value]['cqty'] = $close_count;
									$factor[$value]['comm'] = $bro;
									$factor[$value]['cler'] = $cle;
									$factor[$value]['exc'] 	= $exc;
									$factor[$value]['trx']	= $tra ;
									$factor[$value]['nfa']	= $nfa ;
									$factor[$value]['total_fee']	= $total_fee ;
									$factor[$value]['gpl']	= $gpl ; 
									$factor[$value]['npl']	= $npl ;
									$factor[$value]['date'] = trim($date->datetime);
									 
								}
								
								// print_r($factor);
								array_push($finalshowArray, $factor);										
																		
								$factor = json_encode($factor)  ;
								$factor = json_decode($factor)  ;
								$contractholdArr = array();
								foreach ($factor as $key => $fac) {
									$arr = array(
										'client_id' => 	$fac->client_id,
										'contract_name' =>  $fac->contract,
										'total_contract' => $fac->qty,
										'close_contract' => $fac->cqty,
										'total_comm' => $fac->comm,
										'total_clear' => $fac->cler,
										'total_exe' => $fac->exc,
										'total_txn' => $fac->trx,
										'total_nfa' => $fac->nfa,
										'total_fee' => $fac->total_fee,
										'total_gpl' => $fac->gpl,
										'trade_date' => $date->datetime,
										'total_npl' => $fac->npl
									);
								 	$insert_id ='' ;
									$this->db->insert('contract_wise_dete_report', $arr);
									$insert_id = $this->db->insert_id();
									foreach ($caluContractArr as $key => $val) {
										$insertArr = array(
											'client_date_wise_id' => $insert_id,
											'client_id' => $fac->client_id,
											'contarct_id' => $val['id'],
											'close_id' => $val['close_id'],
											'buy_price' => $val['buy'],
											'sale_price' => $val['sale'],
											'buy_count' => $val['buyqty'],
											'sale_count' => $val['saleqty'],
											'final_qty' => $val['qty'],
											'buy_sale_diff' => $val['diff'],
											'product_name' => $val['contract'],
											'tick_data' => $tick_data,
											'fcm' => $val['fcm'],
											'trade_date' => $date->datetime,
											'trade_type' => $val['open_close_hold']
										);
										$this->admin->SaveOutput($insertArr);

										if($val['open_close_hold'] == 'hold' ){
										 	$long_short = ($val['buyqty'] == '0' ? 'S' : 'B');
										 	$crdr = ($val['buyqty'] == '0' ? 'CR' : 'DR');
										 	$price = ($val['buy'] == '0' ?  $val['sale']  : $val['buy']);
										 	$final_qty = ($val['buyqty'] == '0' ?  $val['saleqty']  : $val['buyqty']);
										 	$contract = $val['pname'] ;
										 	$close_price = $this->getClosingPriceOfContract($contract, $date->datetime);
										 	$price_diff = $price - $close_price ;
										 	$pnl = round(($tick['tick_value'] * ( $price_diff / $tick['tick_size'])), 2) * $qty ;
										 	if($long_short == 'B'){
												$open_trade_equity  -= $pnl ;
										 	}else if($long_short == 'S'){
												$open_trade_equity  += $pnl ;
										 	}



											$contractholdArr = array(
												'client_id' 	=> $fac->client_id,
												'contarct_id' 	=> $val['id'],
												'price' 		=> $price,
												'close_price' 	=> $close_price,
												'price_diff' 	=> $price_diff,
												'profit_loss' 	=> $pnl,
												'debit_credit' 	=> $crdr,
												'quantity' 		=> $qty,
												'fcm' 			=> $val['fcm'],
												'contract' 		=> $contract,
												'long_short' 	=> $long_short,
												'trade_date' 	=> $val['date'],
												'datetime' 		=> $val['date']
												 
											);	
											//$finalholdArray[] = $contractholdArr ;
											 array_push($finalholdArray, $contractholdArr);						 
											$this->admin->SaveOutputHold($contractholdArr);
											//print_r('HOLDING ARRAY' ."<br>");
											//print_r($contractholdArr);
											//$this->admin->updateStatus($v, array('today_Status' => 0));
										}	 
									}
								}
								error_log(print_r('contractholdArr', true));
								error_log(print_r($contractholdArr, true));
								//print_r($finalholdArray);

								/*****************************************************
								Save Closed Trade Here
								******************************************************/
								
							}

							$change_equity = 0 ;
							$net_equity = 0 ;
							$perviousDayNetEquity = 0 ;
							$begining_balance = 0 ;

							$lastday = $this->previouDayRecordClientWise($cliv->name);
							if(count($lastday) > 0){
								$perviousDayNetEquity = $lastday->net_liquidating_value ;
								$begining_balance = $lastday->ending_balance ;
								//$begining_balance = $lastday->ending_balance ;
							}else{
								$perviousDayNetEquity = $this->net_equity ;
								$begining_balance = $this->begining_balance ;
							}

							$final_fee  = $final_comm+$final_clear+$final_exe+$final_nfa+$final_trxn ;
							$final_npl = $final_gpl- $final_fee ;
							$ending_balance = $begining_balance - abs($final_npl);

							if($open_trade_equity > 0){
								$net_equity = ($ending_balance + abs($open_trade_equity)) ;

							}
							else{
								$net_equity = ($ending_balance - abs($open_trade_equity)) ;
							}

							$change_equity = $perviousDayNetEquity - $net_equity ;


							$client_day_calculation['client_id'] = trim($cliv->name) ;
							$client_day_calculation['opening_balance'] = $begining_balance ;
							$client_day_calculation['commission'] = $final_comm ;
							$client_day_calculation['clearing_fee'] = $final_clear ;
							$client_day_calculation['exchange_fee'] = $final_exe ;
							$client_day_calculation['nfa_fee'] = $final_nfa ;
							$client_day_calculation['transactional_fee'] = $final_trxn ;
							$client_day_calculation['total_fee'] = $final_fee ;
							$client_day_calculation['gpl'] = $final_gpl ;
							$client_day_calculation['npl'] = $final_npl ;
							$client_day_calculation['ending_balance'] = $ending_balance ;
							$client_day_calculation['open_trade_equity'] = $open_trade_equity ;
							$client_day_calculation['total_equity'] = $net_equity ;
							
							$client_day_calculation['net_liquidating_value'] = $net_equity ;
							$client_day_calculation['change_from_previous_net_liq'] = $change_equity;
							$client_day_calculation['inital_margin_req'] = 0 ;
							$client_day_calculation['maintenance_margin_req'] = 0 ;
							$client_day_calculation['margin_deficit'] = 0 ;
							$client_day_calculation['mtd_comm'] = 0 ;
							$client_day_calculation['trade_date'] = $date->datetime ;

							$this->db->insert('daily_client_wise_trxn', $client_day_calculation);	
							 
						}
					}
					//print_r(array('error' => true, 'message' => 'No Broker Name Found' ));exit();
				}	// first foreach loop for broker list. Close here 
			}
			//print_r(array('error' => true, 'message' => 'no more record found' ));exit();
		}

		echo json_encode(array("error" => false, "message" => "Trade Calculate Successfully Done ","n_arr" => $client_day_calculation, "arr" => $finalshowArray, "hold" => $finalholdArray)); exit();
		//return $this->response ;
		 

	}

	

	private function getTradeRecordsCalculation($client_name, $date, $contract)
	{
		if($this->checkAdminLogin() != true)
			redirect('login');

		$newdata = [] ;
		$buyarr = [] ;
		$salearr = [] ;
		$buyarrCount = 0;
		$salearrCount = 0;
		
 		$datalist = $this->client->getDatafromDatatable($client_name, $date, $contract); //
 		$original_arr = $datalist;
		foreach ($datalist as $k => $v) {
			$qty = $v['qty'] ;
			for ($i=0; $i <$qty ; $i++) { 
				$newdata[] = $datalist[$k];
				
				if(trim($v['long_short']) =='B'){
					$buyarr[] = $datalist[$k];
				} 
				else if(trim($v['long_short']) =='S'){
					$salearr[] = $datalist[$k];
				} 
			}
		}

		$datalist = $newdata;
		$clint_data = $datalist;

		$buyarrCount = count($buyarr);
		$salearrCount = count($salearr);
		 
		if(count($this->holdContract) > 0){
			$b_ind =  $buyarrCount ;
			$s_ind =  $salearrCount ;
			for ($h=0; $h < count($this->holdContract) ; $h++) { 
				

				$qty = $this->holdContract[$h]['qty'] ;
				for ($i=0; $i <$qty ; $i++) { 
					if($this->holdContract[$h]['long_short'] == 'B'){
						$buyarr[$b_ind] = $this->holdContract[$h];		
						$b_ind ++ ;
					}
					else if($this->holdContract[$h]['long_short'] == 'S'){
						$salearr[$s_ind] = $this->holdContract[$h];
						$s_ind ++ ;
					}
					
					
				}
			}
		}

		$buyarrCount = count($buyarr);
		$salearrCount = count($salearr);
		
		if($datalist != false){

			$count = count($datalist);
			if($count > 0){

				// Loop Convetred into single entry 
				 
				$arrp 	= array(); 	// Product Array 
				$holdingArr 	= array(); 	// Product Array 
				//$newdata 	= array(); 	// Product Array 
				
			 				 
				$buy 	= 0;
				$sale 	= 0;

				$buyPrice 	= 0;
				$salePrice 	= 0;
				$holding = false ;
	
					$arrp 	= array();

					$buySaleDiff = 0;

					$id = $v['id'] ;
					 
					$arr 	= [];			// Final Array
					// In case of buy Count Is More Than a sale count
					if($buyarrCount > $salearrCount){						 
						$dif =   $buyarrCount - $salearrCount ;

						foreach ($buyarr as $k => $v) {
							 
							$arrp 	= array();
							 
							$buyCount 		= 0;
							$saleCount 		= 0;
							$buySalePrice 	= 0;
							$buySaleCount 	= 0;
							$saleBuyPrice 	= 0;
							$SaleBuyCount 	= 0;

							$id = $k ;
							if(count($salearr) == 0){
								$holding = true ;
							}
							$buyPrice 	= $v['total_price']    ;
						
							for ($i=0; $i < count($salearr) ; $i++) {
								$buySaleCount 	= $salearr[$i]['qty']  ;
								//echo "BUY ".$clint_data[$i]['contract']."<br>";
								
								if(trim($v['contract']) == trim($salearr[$i]['contract']) && trim($salearr[$i]['long_short']) == 'S' && $salearr[$i]['work_status'] == '1' ){
									$buySalePrice 	= $salearr[$i]['total_price']    ;
									$salearr[$i]['work_status'] = '0' ;
									$close_id = $salearr[$i]['id'];
									array_push($arrp, $salearr[$i]['contract'].'_S');
									$buySaleDiff = $buySalePrice - $buyPrice ;
									$open_close_hold = 'close' ;

									$holding = false ;
									break;
								}
								else{
									//echo "FIND SALE ELSE $i ". $salearr[$i]['contract']."<br>" ;
									//echo "FIND SALE ELSE $i ". $v['contract']."<br>" ;
									$holding = true ;
								}
							}
						

							if($holding == true){								
								array_push($arrp, $v['contract'].'_H');								
								$buyPrice = $v['total_price'] ;
								$buyCount = $v['qty'] ;
								$buySaleCount = 0 ;
								$buySalePrice = 0 ;
								$open_close_hold = 'hold' ;								
								$close_id = 'hold' ;								
								$holdingArr[] = $buyarr[$k];
								$buySaleDiff = 0;
							}
								
							$arr[$id]['id'] 	= $v['id'] ;
							$arr[$id]['close_id'] 	= $close_id ;
							$arr[$id]['open_close_hold'] 	= $open_close_hold ;
						 	$arr[$id]['contract'] 	= implode($arrp, "|") ;
						 	$arr[$id]['pname'] 		=  $v['contract'];
						 	$arr[$id]['date'] 		=  $v['datetime'];
							$arr[$id]['buy'] 		= $buyPrice ;
							$arr[$id]['sale'] 		= $buySalePrice ;
							$arr[$id]['buyqty'] 	= $buyCount ;
							$arr[$id]['saleqty'] 	= $buySaleCount ;
							$arr[$id]['fcm'] 		= $v['fcm'] ;
							$arr[$id]['diff'] 		= $buySaleDiff ;

						} // for each loop close 
						// START EXTRA CLASS  
						if($dif > 0 && $salearrCount > 0){
							$id = count($arr);
							
							 	if(count($salearr) > 0){
									for ($j=0; $j < count($salearr) ; $j++) { 
										//$id += $j  ;
									 

										if($salearr[$j]['work_status'] == 1 ){
									 	 
											$holdingArr[] = $salearr[$j];
											//$arr[$id]     
											$arr[$id]['id'] 		= $salearr[$j]['id'] ;
											$arr[$id]['close_id'] 	= 'hold' ;
											$arr[$id]['open_close_hold'] 	= 'hold' ;
											$arr[$id]['pname'] 		= $salearr[$j]['contract'];
						 					$arr[$id]['date'] 		= $salearr[$j]['datetime'];
											$arr[$id]['contract'] 	= $salearr[$j]['contract'].'_H' ;
											$arr[$id]['buy'] 		= $salearr[$j]['total_price'] ;
											$arr[$id]['sale'] 		= 0 ;
											$arr[$id]['buyqty'] 	= $salearr[$j]['qty'] ;
											$arr[$id]['saleqty'] 	= 0 ;
											$arr[$id]['fcm'] 		= $salearr[$j]['fcm'] ;
											$arr[$id]['diff'] 		= 0 ;
											$id++;
										}
									}
								}
							 
						}
						// CLOSE EXTRA CLASS 

					}
					// In case of Sale Count Is More Than a Buy count
					else if($buyarrCount < $salearrCount){
						$dif = $salearrCount - $buyarrCount  ;
						  
						foreach ($salearr as $k => $v) {

							$arrp 	= array();
							$buyCount = 0;
							$saleCount = 0;
							$buySalePrice = 0;
							$buySaleCount = 0;
							$saleBuyPrice = 0;
							$SaleBuyCount = 0;
 
							$salePrice = $v['total_price'] ;
							$saleCount = $v['qty'] ;
							array_push($arrp, $v['contract'].'_S');
							$id = $k ;
							if(count($buyarr) == 0){
								$holding = true ;
							}
							//print_r($buyarr);
							for ($i=0; $i < count($buyarr) ; $i++) {
								// for sale contract
								
								$SaleBuyCount 	= $buyarr[$i]['qty']  ;

								 
								if($v['contract'] == $buyarr[$i]['contract'] && $buyarr[$i]['long_short'] =='B' && $buyarr[$i]['work_status'] == '1'){
									
									$saleBuyPrice 	= $buyarr[$i]['total_price']    ;
									$buyarr[$i]['work_status'] = '0' ;
									$close_id = $buyarr[$i]['id'];
									array_push($arrp, $buyarr[$i]['contract'].'_B');
									$buySaleDiff = $salePrice - $saleBuyPrice ;
									$open_close_hold = 'close' ;
									$holding = false ;
									break;
								}
								else{
									 
									$holding = true ;
								}
							}
							
							
							if($holding == true){
								

								array_push($arrp, $v['contract'].'_H');
								$clint_data[$k]['work_status'] = 'h' ;
								$open_close_hold = 'hold' ;
								$close_id = 'hold' ;
								$salePrice = $v['total_price'] ;
								$saleCount = $v['qty'] ;
								$saleBuyPrice = 0 ;
								$SaleBuyCount = 0 ;
								
								$holdingArr[] = $salearr[$k];
								$buySaleDiff = 0;
							}
							$arr[$id]['id'] 	= $v['id'] ;
							$arr[$id]['close_id'] 	= $close_id ;
							$arr[$id]['open_close_hold'] 	= $open_close_hold ;
							$arr[$id]['pname'] 		= $v['contract'];
						 	$arr[$id]['date'] 		= $v['datetime'];
							$arr[$id]['contract'] 	= implode($arrp, "|") ;
							$arr[$id]['buy'] 		= $saleBuyPrice ;
							$arr[$id]['sale'] 		= $salePrice ;
							$arr[$id]['buyqty'] 	= $SaleBuyCount ;
							$arr[$id]['saleqty'] 	= $saleCount ;
							$arr[$id]['fcm'] 		= $v['fcm'] ;
							$arr[$id]['diff'] 		= $buySaleDiff ;
					 
					    }
					   

					    // for each loop close 
					   
						if($dif > 0 && $buyarrCount > 0){
							 
							$id = count($arr);
							
							 	if(count($buyarr) > 0){
									for ($j=0; $j < count($buyarr) ; $j++) { 
										//$id += $j  ;
									 

										if($buyarr[$j]['work_status'] == 1 ){
									 	 
											$holdingArr[] = $buyarr[$j];
											//$arr[$id]     
											$arr[$id]['id'] 		= $buyarr[$j]['id'] ;
											$arr[$id]['close_id'] 	= 'hold' ;
											$arr[$id]['open_close_hold'] 	= 'hold' ;
											$arr[$id]['pname'] 		= $buyarr[$j]['contract'];
						 					$arr[$id]['date'] 		= $buyarr[$j]['datetime'];					
						 					$arr[$id]['contract'] 	= $buyarr[$j]['contract'].'_H' ;
											$arr[$id]['buy'] 		= $buyarr[$j]['total_price'] ;
											$arr[$id]['sale'] 		= 0 ;
											$arr[$id]['buyqty'] 	= $buyarr[$j]['qty'] ;
											$arr[$id]['saleqty'] 	= 0 ;
											$arr[$id]['fcm'] 		= $buyarr[$j]['fcm'] ;
											$arr[$id]['diff'] 		= 0 ;
											$id++;
										}
									}
								}
							 
						}
					}
					// In case of Sale AND BUY count Are Equal
					else{
						$saleholdingArr = [];
						/*print_r("BUY ARRAY BEROFE PROCESS +=========================================<br>");
						print_r($buyarr);*/
					 	// If In case of Buy and sale both of same size of array
						foreach ($salearr as $k => $v) {
							 
							$arrp 			= array();
							$buyCount 		= 0;
							$saleCount 		= 0;
							$buySalePrice 	= 0;
							$buySaleCount 	= 0;
							$saleBuyPrice 	= 0;
							$SaleBuyCount 	= 0;

							$id = $k ;
							$salePrice = $v['total_price'] ;
							$saleCount = $v['qty'] ;
							array_push($arrp, $v['contract'].'_S');

							for ($i=0; $i < count($buyarr) ; $i++) {
								// for sale contract
								$SaleBuyCount 	= $buyarr[$i]['qty']  ;
								 
								if(trim($v['contract']) == trim($buyarr[$i]['contract']) && trim($buyarr[$i]['long_short']) =='B' && $buyarr[$i]['work_status'] == '1'){
									 
								
									$saleBuyPrice 	= $buyarr[$i]['total_price']    ;
									$buyarr[$i]['work_status'] = '0' ;
									$close_id = $buyarr[$i]['id'];
									//$clint_data[$i]['hold_unhold'] = '0';
									array_push($arrp, $buyarr[$i]['contract'].'_B');
									$buySaleDiff = $salePrice - $saleBuyPrice ;
									$open_close_hold = 'close' ;
									$holding = false ;
									break;
								}
								else{
									
									$holding = true ;
								}
							}	/* For loop Close here */

							if($holding == true){
								array_push($arrp, $v['contract'].'_H');
								//$buyarr[$k]['work_status'] = 'h' ;
								$open_close_hold = 'hold' ;
								
								$holdingArr[] = $salearr[$k];
								// $saleholdingArr[] = $salearr[$k];
								$buySaleDiff = 0;
								$close_id = 'hold' ;
							}
							$arr[$id]['id'] 	= $v['id'] ;
							$arr[$id]['close_id'] 	= $close_id ;
							$arr[$id]['open_close_hold'] 	= $open_close_hold ;
							$arr[$id]['pname'] 		= $v['contract'];
						 	$arr[$id]['date'] 		= $v['datetime'];
							$arr[$id]['contract'] 	= implode($arrp, "|") ;
							$arr[$id]['buy'] 		= $saleBuyPrice ;
							$arr[$id]['sale'] 		= $salePrice ;
							$arr[$id]['buyqty'] 	= $SaleBuyCount ;
							$arr[$id]['saleqty'] 	= $saleCount ;
							$arr[$id]['fcm'] 		= $v['fcm'] ;
							$arr[$id]['diff'] 		= $buySaleDiff ;
					    }	// Close For each loop 

					    // print_r("salearr ===================================================================<br>");
					    // print_r($salearr);
					    // print_r("BUY ARRA ===================================================================<br>");
					    //print_r($buyarr);

					    $hcount = count($holdingArr);
					    $acount = count($arr);
					    if(count($buyarr) > 0){
					    	for ($i=0; $i < count($buyarr) ; $i++) { 
					    		
					    		// holding array 
					    		//print_r("IN IF FOR LOOP  CASE =================".$buyarr[$i]['work_status']."==============================>>>>>>>>><br>");
					    		if($buyarr[$i]['work_status'] == '1'){
					    			//print_r("IN IF CASE ===============================================>>>>>>>>><br>");
					    			$buyarr[$i]['work_status'] = '0' ; 
						    		$holdingArr[$hcount] = $buyarr[$i];

						    		$arr[$acount]['id'] 		= $buyarr[$i]['id'] ;
						    		$arr[$acount]['close_id'] 	= 'hold' ;
									$arr[$acount]['open_close_hold'] 	= 'hold' ;
									$arr[$acount]['pname'] 			= $buyarr[$i]['contract'];
						 			$arr[$acount]['date'] 			= $buyarr[$i]['datetime'];
									$arr[$acount]['contract'] 	= $buyarr[$i]['contract'].'_B' ;
									$arr[$acount]['buy'] 		= $buyarr[$i]['total_price'] ;
									$arr[$acount]['sale'] 		= 0 ;
									$arr[$acount]['buyqty'] 	= $buyarr[$i]['qty'] ;
									$arr[$acount]['saleqty'] 	= 0 ;
									$arr[$acount]['fcm'] 		= $buyarr[$i]['fcm'] ;
									$arr[$acount]['diff'] 		= 0 ;
									$acount++;
					    			$hcount++;
					    		}
					    		


					    		
					    	}
					    }

					}

					// print_r("BUY COUNT  " . count($buyarr)."<br>");
					// print_r( $buyarr);
					// print_r("SALE COUNT " . count($salearr)."<br>");
					// print_r($salearr);
					// print_r("saleholdingArr" . count($salearr)."<br>");
					/*print_r("SALLER HOLDING   " . count($buyarr)."<br>");
					print_r($saleholdingArr);
					print_r("TOTAL  HOLDING   " . count($buyarr)."<br>");
					print_r($holdingArr);
					print_r("Calculate   " . count($buyarr)."<br>");
					print_r($arr);*/
					// calculation array compare with origenal array and calculate final diff


					 
					
					
					//echo "<br>LOOP CLOSE ========================================================<br><br><br><br> ";

					// echo "BUY : $buy <br>";
					//$arr[$id]['contract'] 	= implode($arrp, "|") ;, 'client' => $clint_data
					
					
				//}'org' => $original_arr ,
				
				   //print_r(array('calcu' => $arr, 'holding' => $holdingArr, 'client' => $clint_data )) ;
				return array('org' => $original_arr ,  'calcu' => $arr , 'holding' => $holdingArr ) ;
				
			}	
		}
		return array("error" => false, "message" => "no more record to calculate NPL & GPL ");
	}
		 
		 


	

	/*public function SaleHoldingCrossCheck($salehold='', $clint_data)
	{
		$count = count($salehold);

		for ($i=0; $i < $count; $i++) { 
			// for sale contract
			$SaleBuyCount 	= $clint_data[$i]['qty']  ;
			//echo "SALE ".$clint_data[$i]['contract']."<br>";	
			if($v['contract'] == $clint_data[$i]['contract'] && $clint_data[$i]['long_short'] =='B' && $clint_data[$i]['work_status'] == '1'){
				//echo "FIND BUY $i ". $clint_data[$i]['contract']."<br>" ;
				$saleBuyPrice 	= $clint_data[$i]['total_price']    ;
			
				 
				break;
			}
			else{
				//echo "FIND BUY $i ". $clint_data[$i]['contract']."<br>" ;
				$holding = true ;
			} 
			 
			
		}
	}*/

	public function currentHolding($value='')
	{
		if($this->checkAdminLogin() != true)
			redirect('login');


		$data['title'] = "Holding" ;
		$data['pageheader'] = "Current Holding" ;
		$data['holdings'] = $this->contract->activeHolding() ;

		$this->load->view('pages/reports/current_holding', $data);
	}
		 

	 
}


