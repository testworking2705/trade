<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Report extends MY_Controller {

	public function __construct($value='')
	{
		parent::__construct();
		// $this->load->model('AuthModel', 'am');
		//$this->load->model("math_model");	
	}
	 
	public function index()
	{
		//print_r($this->client->getClients());
		$closeTrades = $this->report->closeTrade();
		$holdTrades = $this->report->holdTrade();

		print_r(array_merge($closeTrades, $holdTrades));
		//$this->load->view('pages/dashboard');
	}

	public function dateWiseReport($value='')
	{
		$data['title'] = "Report" ;
		$data['pageheader'] = "Day Wise Report" ;
		$data['clients'] = $this->client->getClients() ;

		$this->load->view('pages/reports/report', $data);
	}

	// ajax Call for Fetch Report data
	public function getReportData()
	{	
		$from = $this->input->post('from');	
		$to = $this->input->post('to');	
		

		if(empty($from)){
			echo json_encode(array("error" => true, "message" => "Please Select From Date"));exit();
		}

		if(empty($to)){
			echo json_encode(array("error" => true, "message" => "Please Select To Date"));exit();
		}

		if ($to < $from){
			echo json_encode(array('error' => true, "message" => "Please Select Future Date in to "));exit();
		}

		$from = $this->changeDateByFormat2($from);	
		$to = $this->changeDateByFormat2($to);	
		//echo json_encode(array('error' => true, "from" => $from, "to" => $to, "message" => "Please Select Future Date in to "));exit();

		$client_id = $this->input->post('client');	
		if($client_id > 0){
			$data = $this->report->contractWiseReport($from, $to, $client_id);
		}
		else{
			$data = $this->report->contractWiseReport($from, $to);
		}
		//echo json_encode($data);exit();
		if($data!=false){
			print_r(json_encode(array('error' => false, "data" => $data,  "message" => "Record Found")));exit();
		}
		print_r(json_encode(array('error' => true, "data" => $data,  "message" => "Record Not Found")));exit();

	}


	public function contractReport($value='')
	{
		$data['title'] = "Report" ;
		$data['pageheader'] = "Day Wise Report" ;
		$data['clients'] = $this->client->getClients() ;

		$this->load->view('pages/reports/contracts', $data);
	}

	public function contractMonthWise()
	{	
		$from = $this->input->post('from');	
		$to = $this->input->post('to');	
		$ddarr = [];
		

		if(empty($from)){
			echo json_encode(array("error" => true, "message" => "Please Select From Date"));exit();
		}

		if(empty($to)){
			echo json_encode(array("error" => true, "message" => "Please Select To Date"));exit();
		}

		if ($to < $from){
			echo json_encode(array('error' => true, "message" => "Please Select Future Date in to "));exit();
		}

		$from = $this->changeDateByFormat2($from);	
		$to = $this->changeDateByFormat2($to);
		$fdate = $from ;
		for ($i=0; $i < 31 ; $i++) { 
			if($fdate <= $to){
				array_push($ddarr, $fdate) ;
				$fdate = $this->add_date($fdate, "1");
			}
		}
		//print_r(json_encode($dd));exit();	
		//echo json_encode(array('error' => true, "from" => $from, "to" => $to, "message" => "Please Select Future Date in to "));exit();

		$client_id = $this->input->post('client');	
		if($client_id > 0){
			$data = $this->report->contractMonthWise($from, $to, $client_id);
		}
		else{
			$data = $this->report->contractMonthWise($from, $to,$client_id);
		}
		//$dates = $this->getUniqueArrayColumnWiseFromArray($data, 'datetime');
		//print_r(json_encode($data));exit();

		$contracts = $this->getUniqueArrayColumnWiseFromArray($data, 'contract');
		
		
		foreach ($contracts as $ck => $cv) {
			$rarr[$cv] = [] ; 
			foreach ($ddarr as $ddk => $ddv) {
				foreach ($data as $dak => $dav) {
					if($cv == $dav['contract'] && $ddv == $dav['datetime']){
						if(array_key_exists($dav['contract'], $rarr[$cv])){
							$d = array( 'con' => $dav['contract'],  'date' => $dav['datetime'] , 'ct' => $dav['contract_count'] ) ; 
						}
						else{
							$d = array( 'con' => $dav['contract'] , 'date' => $dav['datetime'] , 'ct' => $dav['contract_count'] ) ;
						}
					}
				}
				array_push($rarr[$cv], $d);
			}
		}
		if($data!=false){
			print_r(json_encode(array('error' => false, "data" => $rarr , "ddarr" => $ddarr,  "message" => "Record Found")));exit();
		}
		print_r(json_encode(array('error' => true, "data" => $data,  "message" => "Record Not Found 1")));exit();

		/*$frarr = [];
		foreach ($rarr as $k => $v) {
			//array_push($frarr, $k);
			array_push($frarr, $v);
			foreach ($ddarr as $dk => $dv) {

			}

		}

		print_r(json_encode($frarr)); 
			 
			


	

		// print_r(json_encode($data));
		exit();*/

		

	}
		



	public function daywiseCalulation($from, $to, $client_id)
	{
		$arr = array('trade_date >=' => $from, 'trade_date <=' => $to, 'client' => $client_id );
		$this->db->
		$query = $this->db->get_where('contract_wise_dete_report', $arr);
	}





















	public function daywiseCalulations()
	{
		 
		//print_r($this->client->getClients());
		$data['title'] = "Contract" ;
		$data['pageheader'] = "Add Contract" ;
		
		$clintArr = [];
		$client_list = $this->client->ClientList();
		
		foreach ($client_list as $key => $value) {
			$name = trim($value['name']) ;
			//echo $name ."<br>";
			$closeTrades = $this->report->closeTrade($name);
			$holdTrades = $this->report->holdTrade($name);
			$finalarr = array_merge($closeTrades, $holdTrades) ;
			$clintArr[] = $finalarr ; 
		}
		$data['report'] = $clintArr ;
		//print_r($clintArr);
		/*
		  if(count($clintArr)> 0):
		  	foreach ($clintArr as $k => $v):
		  		// print_r($v[$k]['client_id']) ."<br>";
		  		 //$clintArr[$k]	
		  		 for ($i=0; $i < count($clintArr[$k]) ; $i++) { 
		  		 	//echo $v[$i]['trade_type']."<br>";
		  		 }
              endforeach; 
           endif; */




		$this->load->view('pages/reports/datewise', $data);
		 
	}

	 
}
