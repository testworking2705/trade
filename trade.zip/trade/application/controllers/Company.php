<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Company extends MY_Controller {

	public function __construct($value='')
	{
		parent::__construct();
		//print_r($this->session);
		// $this->load->model('AuthModel', 'am');
		//$this->load->model("math_model");	

	}
	 
	public function index()
	{
		if($this->checkAdminLogin() != true)
			redirect('login');

		$data['title'] = "Company" ;
		$data['pageheader'] = "Company list" ;
		$data['clients'] = $this->company->getList() ;
			
		$this->load->view('pages/admin/company/index', $data);
	}

	public function create($value='')
	{
		if($this->checkAdminLogin() != true)
			redirect('login');

		$data['title'] = "Company" ;
		$data['pageheader'] = "Add Company" ;
		 
		 
		if($this->form_validation->run('company')== true){

			$clientArray = array(
    		'client_id' => $this->input->post('client_id'),
    		'first_name' 		=> $this->input->post('first_name'),
    		'last_name' 	=> $this->input->post('last_name'),
    		'company_associated_with' => $this->input->post('company_associate'),
    		'cid' 		=> $this->input->post('c_id'),
    		'subscription' 	=> $this->input->post('subscription'),
    		'market_data' 		=> $this->input->post('market_data'),
    		'admin_fee' 		=> $this->input->post('admin_fee'),
    		//'others1' 		=> $this->input->post('others'),
    		'commission' 		=> $this->input->post('commision'),
    		'clearing_fee' 		=> $this->input->post('clearingfee'),
    		'exchange_fee' 		=> $this->input->post('exchangefee'),
    		'tradetinal' 		=> $this->input->post('transationalfee'),
    		'nfa' 		=> $this->input->post('nfa'),
    		//'others2' 		=> $this->input->post('pertrade_other'),
    		'address' 		=> $this->input->post('address'),
    		'email' 		=> $this->input->post('email'),
    		'mobile' 		=> $this->input->post('mobile')
    	);
        	 
        		
      		$result = $this->company->create($clientArray) ;
      		if($result){
      			$this->session->set_flashdata('success','Company Created Successfully. ');
      			redirect('client-add');
      		}
      		else{
      			$this->session->set_flashdata('fail','Company Create fail. ');
      			redirect('client-add');

      		}

			$this->load->view('pages/admin/company/create', $data);
		}
		$this->load->view('pages/admin/company/create', $data);
	}


	public function edit()
	{
		if($this->checkAdminLogin() != true)
			redirect('login');

		$data['title'] = "Company" ;
		$data['pageheader'] = "Company Update" ;
		$id = $this->uri->segment(2,0) ;
		$data['id'] = $id;
		$data['company'] = $this->company->getList($id);

		if($this->form_validation->run('company')== true){

			$clientArray = array(
    		'client_id' => $this->input->post('client_id'),
    		'first_name' 		=> $this->input->post('first_name'),
    		'last_name' 	=> $this->input->post('last_name'),
    		'company_associated_with' => $this->input->post('company_associate'),
    		'cid' 		=> $this->input->post('c_id'),
    		'subscription' 	=> $this->input->post('subscription'),
    		'market_data' 		=> $this->input->post('market_data'),
    		'admin_fee' 		=> $this->input->post('admin_fee'),
    		//'others1' 		=> $this->input->post('others'),
    		'commission' 		=> $this->input->post('commision'),
    		'clearing_fee' 		=> $this->input->post('clearingfee'),
    		'exchange_fee' 		=> $this->input->post('exchangefee'),
    		'tradetinal' 		=> $this->input->post('transationalfee'),
    		'nfa' 		=> $this->input->post('nfa'),
    		//'others2' 		=> $this->input->post('pertrade_other'),
    		'address' 		=> $this->input->post('address'),
    		'email' 		=> $this->input->post('email'),
    		'mobile' 		=> $this->input->post('mobile')
    	);
        	 
        		
      		$result = $this->company->update($clientArray, $id) ;
      		if($result){
      			$this->session->set_flashdata('success','Company Update Successfully. ');
      			redirect('company-edit/'.$id);
      		}
      		else{
      			$this->session->set_flashdata('fail','Company Update fail. ');
      			redirect('company-edit/'.$id);

      		}

			$this->load->view('pages/admin/company/edit', $data);
		}

		$this->load->view('pages/admin/company/edit', $data);
	}


	 
}
