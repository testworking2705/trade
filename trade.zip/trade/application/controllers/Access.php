<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Access extends MY_Controller {

	public function __construct($value='')
	{
		parent::__construct();
		//print_r($this->session);
		// $this->load->model('AuthModel', 'am');
		//$this->load->model("math_model");	

	}
	 
	public function index()
	{
		if($this->checkAdminLogin() != true)
			redirect('login');

		$data['title'] = "Client" ;
		$data['pageheader'] = "Client list" ;
		$data['clients'] = $this->client->getClients() ;
		//$data['companies'] = $this->client->getClients() ;
		//$data['contracts'] = $this->client->getClients() ;
		//$data['report'] = $this->client->getClients() ;

		
		$this->load->view('pages/admin/client/index', $data);
	}

	public function create($value='')
	{
		if($this->checkAdminLogin() != true)
			redirect('login');

		$data['title'] = "Access" ;
		$data['pageheader'] = "Add Access" ;
    $data['users'] = $this->user->getUser() ;
    $data['acc'] = $this->mm->getAccess() ;

    //$this->form_validation->set_rules('access[]',"Access", "required|trim|xss_clean|numeric");
  
		if($this->form_validation->run('')== true){
			$Array = array(
    		'user_id'     => $this->input->post('users'),
    		// 'role_id' 		=> $this->input->post('first_name'),
    		'access_id' 	=> $this->input->post('access')
    	);
        	 
        		
      	/*	$result = $this->client->create($Array) ;
      		if($result){
      			$this->session->set_flashdata('success','Client Created Successfully. ');
      			redirect('client-add');
      		}
      		else{
      			$this->session->set_flashdata('fail','Client Create fail. ');
      			redirect('client-add');

      		}*/

			$this->load->view('pages/access/create', $data);
		}
		$this->load->view('pages/access/create', $data);
	}

  /*public function addAccessToUsers($value='')
  {
    //print_r($_POST);
    if(!isset($_POST['access'])){
      echo json_encode(array("error" => true, "message" => "Please Select Access "));exit();
    }
    else if(  count($_POST['access']) == 0 ){
      echo json_encode(array("error" => true, "message" => "Please Select Access  ". count($_POST['access'])));exit();
    }
    else if( trim($_POST['users']) == 0 ){
      echo json_encode(array("error" => true, "message" => "Please Select User "));exit();
    }

    $id = $this->input->post('users');

    $newarr = $_POST['access'] ;
    $string = implode(",", $newarr) ;
    $res = $this->mm->checkExistAccess($id);
    //print_r($res);
    $inserArr = array(
      'user_id' => $id,
      'access_id' => $string,
    );
    if(count($res) > 0){

      $old_acc_arr = explode(',', $res->access_id) ;
     
      $array = array_unique(array_merge($old_acc_arr, $newarr));
      $string = implode(",", $array) ;
        $inserArr = array(
          'access_id' => $string,
        );
      $result = $this->mm->updateUserRights($id, $inserArr);
      //echo json_encode(array("error" => false, "message" => "User Access Update Successfully" ));exit(); 
    }
    else{
     $result =  $this->mm->addUserRights($inserArr);
    }

    
    if($result){
      echo json_encode(array("error" => false, "message" => "User Access Update Successfully" ));exit();
    }
    else{
      echo json_encode(array("error" => true, "message" => "User Access Not Update..." ));exit();
    }





  }*/





	public function edit()
	{
		if($this->checkAdminLogin() != true)
			redirect('login');

		$data['title'] = "Client" ;
		$data['pageheader'] = "Client Update" ;
		$id = $this->uri->segment(2,0) ;
		$data['id'] = $id;
		$data['clients'] = $this->client->getClientById($id);

		if($this->form_validation->run('client')== true){

			$clientArray = array(
    		'client_id' => $this->input->post('client_id'),
    		'first_name' 		=> $this->input->post('first_name'),
    		'last_name' 	=> $this->input->post('last_name'),
    		'company_associated_with' => $this->input->post('company_associate'),
    		'cid' 		=> $this->input->post('c_id'),
    		'subscription' 	=> $this->input->post('subscription'),
    		'market_data' 		=> $this->input->post('market_data'),
    		'admin_fee' 		=> $this->input->post('admin_fee'),
    		'others1' 		=> $this->input->post('others'),
    		'commission' 		=> $this->input->post('commision'),
    		'clearing_fee' 		=> $this->input->post('clearingfee'),
    		'exchange_fee' 		=> $this->input->post('exchangefee'),
    		'tradetinal' 		=> $this->input->post('transationalfee'),
    		'nfa' 		=> $this->input->post('nfa'),
    		'others2' 		=> $this->input->post('pertrade_other'),
    		'address' 		=> $this->input->post('address'),
    		'email' 		=> $this->input->post('email'),
    		'mobile' 		=> $this->input->post('mobile')
    	);
        	 
        		
      		$result = $this->client->update($clientArray, $id) ;
      		if($result){
      			$this->session->set_flashdata('success','Client Update Successfully. ');
      			redirect('client-edit/'.$id);
      		}
      		else{
      			$this->session->set_flashdata('fail','Client Update fail. ');
      			redirect('client-edit/'.$id);

      		}

			$this->load->view('pages/admin/client/edit', $data);
		}

		$this->load->view('pages/admin/client/edit', $data);
	}


	 
}
