<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends MY_Controller {

	public function __construct($value='')
	{
		parent::__construct();
		//$this->load->model('AuthModel', 'am');
		//$this->load->model("math_model");	
	}
	 
	public function index()
	{
		if($this->checkAdminLogin() == true)
			redirect('dashboard');

		$this->load->view('front/auth/login');
	}

	public function login($value='')
	{	
		if($this->checkAdminLogin() == true)
			redirect('dashboard');
        
		$this->load->library('form_validation');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[8]|max_length[15]',
                array(
                	'required' => 'You must provide a %s.',
                	'min_length' => 'Password must be greater than or equal to 8 char..',
                	'max_length' => 'Password max length is 15 char..'
            		)
        );
        
        $this->form_validation->set_error_delimiters('<p class="error">', '</p>'); 

		if($this->form_validation->run()== true){
			$user = $this->am->login($this->input->post('email'), $this->input->post('password'));
			
			if($user != false && count($user) > 0 ){	
			// print_r($user);exit();			
				$array = array(
					'admin' => $user,
					'admin_logedIn' => 1
				);
				$this->createSession($array);
				//print_r($this->session->admin_logedIn);	
				redirect('dashboard');
			}
			else{
				$this->load->view('front/auth/login');
			}

		}
		else{
			 
			$this->load->view('front/auth/login');

		}
	}

	// Delete All File Here 

	public function DeleteRecords()
	{
		//echo json_encode(array("error" => false, "message" => "Record Deleted...")); exit();
		$id = $this->input->post('id');
		$filename = $this->input->post('filename');
		if($filename == 'client'){
			$response = $this->client->delete($id);
		}else if($filename == 'company'){
			$response = $this->company->delete($id);
		}else if($filename == 'contract'){
			$response = $this->contract->delete($id);
		}else if($filename == 'user'){
			$response = $this->user->delete($id);
		}
		if($response){
			echo json_encode(array("error" => false, "message" => "$response Record Deleted..."));
		}else {
			echo json_encode(array("error" => true, "message" => "$response Record Not Deleted..."));
		}
			
	}

	public function logout($value='')
	{
		$array_items = array('admin_logedIn', 'admin');
		$this->session->unset_userdata($array_items);
		
		redirect('login');
	}
		
}
