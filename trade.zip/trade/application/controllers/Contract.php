<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Contract extends MY_Controller {

	public function __construct($value='')
	{
		parent::__construct();
		//print_r($this->session);
		// $this->load->model('AuthModel', 'am');
		//$this->load->model("math_model");	

	}

	function check_default($post_string)
	{
	  return $post_string == '0' ? FALSE : TRUE;
	}
	 
	public function index()
	{
		if($this->checkAdminLogin() != true)
			redirect('login');

		$data['title'] = "Contract" ;
		$data['pageheader'] = "Contracts List" ;
		$data['contracts'] = $this->contract->getContracts() ;

		$this->load->view('pages/admin/contract/contracts', $data);

	}





	public function add_contract()
	{
		if($this->checkAdminLogin() != true)
			redirect('login');

		
		$data['title'] = "Contract" ;
		$data['pageheader'] = "Add Contract" ;
		$data['currency'] = $this->mm->currency() ;
		
        if($this->form_validation->run('contract')== true){
        	$contractArray = array(
        		'contract_name' => $this->input->post('contract_name'),
        		'code' 		=> $this->input->post('code'),
        		'tick_size' 	=> $this->input->post('tick_size'),
        		'tick_value' 	=> $this->input->post('tick_value'),
            'contract_margin'    => $this->input->post('contract_margin'),
        		'contract_cycle' => $this->input->post('contract_cycle'),
        		'currency' 	=> $this->input->post('currency'),
        		'first_notice' 	=> $this->input->post('first_notice'),
        		'expiry' 	=> $this->input->post('expiry')
        	);
        		$contract_id =  $this->input->post('contract_id');
        		if($contract_id > 0){
        			$result = $this->contract->update($contractArray) ;
        		}
        		else{
        			$result = $this->contract->create($contractArray) ;
        		}

        		if($result){
        			$this->session->set_flashdata('success','Contract Added Successfully. ');
        			redirect('contract-add');
        		}
        		else{
        			$this->session->set_flashdata('fail','Contract Added fail. ');
        			redirect('contract-add');

        		}

			$this->load->view('pages/admin/contract/add_product', $data);
        }
        
		$this->load->view('pages/admin/contract/add_product', $data);
	}

	public function update_contract()
	{
		if($this->checkAdminLogin() != true)
			redirect('login');

		$data['title'] = "Contract" ;
		$data['pageheader'] = "Update Contract" ;
		$data['currency'] = $this->mm->currency() ;

		$id = $this->uri->segment(2,0) ;
		$data['id'] = $id;
		$data['contract_info'] = $this->contract->getContracts($id);
		
        if($this->form_validation->run('contract')== true){
        	 
        	$contractArray = array(
        		'contract_name' => $this->input->post('contract_name'),
        		'code' 		=> $this->input->post('code'),
        		'tick_size' 	=> $this->input->post('tick_size'),
        		'tick_value' 	=> $this->input->post('tick_value'),
        		'contract_cycle' => $this->input->post('contract_cycle'),
        		'currency' 		=> $this->input->post('currency'),
        		'first_notice' 	=> $this->input->post('first_notice'),
        		'expiry' 		=> $this->input->post('expiry')
        	);
        		$contract_id =  $this->input->post('contract_id');
        		
        		$result = $this->contract->update($contractArray, $contract_id ) ;
        		if($result){
        			$this->session->set_flashdata('success','Contract Update Successfully. ');
        			redirect('contract-edit/'.$id);
        		}
        		else{
        			$this->session->set_flashdata('fail','Contract Update fail. ');
        			redirect('contract-edit/'.$id);

        		}

			$this->load->view('pages/admin/contract/contract_edit', $data);
        }
        
		$this->load->view('pages/admin/contract/contract_edit', $data);


	}



	 
}
