<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends MY_Controller {

	public function __construct($value='')
	{
		parent::__construct();
		//print_r($this->session);
		// $this->load->model('AuthModel', 'am');
		//$this->load->model("math_model");	

	}
	 
	public function index()
	{
		if($this->checkAdminLogin() != true)
			redirect('login');

		$data['title'] = "Dashboard" ;
		$data['pageheader'] = "Dashboard" ;
		$data['clients'] = $this->client->getClients() ;
		$data['companies'] = $this->company->getList() ;
		$data['contracts'] = $this->contract->getContracts() ;
		$data['report'] = $this->client->getClients() ;


		$this->load->view('pages/dashboard', $data);
	}


	public function clientList($value='')
	{
		print_r(json_encode($this->client->getClients())) ;
	}

	public function companyList($value='')
	{
		print_r(json_encode($this->company->getList())) ;
	}

	public function contractList($value='')
	{
		print_r(json_encode($this->contract->getContracts())) ;
	}

	 
}
