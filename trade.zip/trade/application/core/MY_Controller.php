<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends CI_Controller {

	public function __construct($value='')
	{
		parent::__construct();
		$this->load->model('AuthModel', 'am');
		$this->load->model('AdminModel', 'admin');
		$this->load->model('UploadModel', 'upload');
		$this->load->model('ClientModel', 'client');
		$this->load->model('ReportModel', 'report');
		$this->load->model('MasterModel', 'mm');
		$this->load->model('ProductModel', 'product');
		$this->load->model('ContractModel', 'contract');
		$this->load->model('CompanyModel', 'company');
		$this->load->model('UserModel', 'user');

		$language = 'english' ;
		$this->load->helper('language');
		$this->load->helper('directory');
		
		$this->config->set_item('language', $language);
        $map = directory_map(APPPATH . "./language/" . $language . "/app_files");
        foreach ($map as $lang_key => $lang_value) {
            $lang_array[] = 'app_files/' . str_replace(".php", "", $lang_value);
        }
        $this->load->language($lang_array, $language);
		//$this->lang->load('english', 'language');

        //print_r($closing);

		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="error">', '</p>'); 
		//$this->load->model("math_model");	
	}

	public function check_input($data='')
	{
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}

	public function checkDateFormat($date, $seprator)
	{
	    $strd = explode("$seprator", $date);
		if(strlen(trim($date)) == '8'){
	        if($strd['2'] == '20'){
	            $m = $strd['0'] ;
	            $d = $strd['1'] ;
	            $y = $strd['2'].'20' ;
	            $date = $y .'-'. $m .'-'. $d ;
	        }
	        return $date ;
	    } 
            $m = $strd['0'] ;
            $d = $strd['1'] ;
            $y = $strd['2'];
            $date = $y .'-'. $m .'-'. $d ;
       	return $date ;  
	}   

	function changeDateByFormat($date)
	{
	    if(strpos($date, "/")){
	    	$date = $this->checkDateFormat($date, "/");
	    	$date = date('Y-m-d', strtotime($date)) ;
        }elseif(strpos($date, "-")){
	    	$date = $this->checkDateFormat($date, "-");

	    	$date = date('Y-m-d', strtotime($date)) ;
	    }
	    return  $date ; 
	}

	function changeDateByFormat2($date) // dd-mm-yyyy input format
	{
	    if(strpos($date, "/")){
	    	//$date = $this->checkDateFormat($date, "/");
	    	$date = date('Y-m-d', strtotime($date)) ;
        }elseif(strpos($date, "-")){
	    	// $date = $this->checkDateFormat($date, "-");

	    	$date = date('Y-m-d', strtotime($date)) ;
	    }
	    return  $date ; 
	}

	public function getUniqueArrayColumnWiseFromArray($array, $column_name)
	{
		if(count($array) > 0  && strlen($column_name) > 0 ){
			$array = array_column($array, $column_name);
			return array_unique($array);	
		}
		return "Both Parameters are required.";
	}

	public function createSession($data='')
	{
		$this->session->set_userdata($data);
	}

	public function checkAdminLogin($value='')
	{
		if($this->session->admin_logedIn)
			return true ;
		else
			return false ;
	}

	/*
	Get date Diff Between Two Days 
	*/
	public function daydifference($from, $to)
	{
		$date1=date_create(date('Y-m-d', strtotime($from)));
		$date2=date_create(date('Y-m-d', strtotime($to)));
		$diff=date_diff($date1,$date2);
		echo $diff->format("%a");
	}

	public function add_date($date, $days)
	{
		$date = date_create(date('Y-m-d', strtotime($date)));
		date_add($date,date_interval_create_from_date_string($days." days"));
		return date_format($date,"Y-m-d");
	}

	
	 
	
}
