<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'welcome';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['login'] = 'welcome/login';
$route['logout'] = 'welcome/logout';
$route['gpl'] = 'OutCome/calculate_gpl';
$route['getrecord'] = 'OutCome/getTradeRecords';
$route['calculation'] = 'OutCome/FinalCaulation';


//  Report Route
$route['daywise'] = 'Report/daywiseCalulation';
$route['report'] = 'Report/dateWiseReport';
$route['contracts'] = 'Report/contractReport';


//  Dashboard Route
$route['dashboard'] = 'dashboard';

// Trades route 
$route['trades-upload'] = 'UploadData/fileupload';
$route['close-price'] = 'UploadData/closingPrice';
$route['trade-view'] = 'UploadData';


//  OutCome Route
$route['cal-view'] = 'outcome';
$route['hold-view'] = 'outcome/currentHolding';


//  Contract Route
$route['contract-view'] = 'Contract';
$route['contract-add'] = 'Contract/add_contract';
$route['contract-edit/(:any)'] = 'Contract/update_contract';

//  Client Route
$route['client-view'] = 'client';
$route['client-add'] = 'client/create';
$route['client-edit/(:any)'] = 'client/edit';

//  Company Route
$route['company-view'] = 'company';
$route['company-add'] = 'company/create';
$route['company-edit/(:any)'] = 'company/edit';


//  User Route
$route['user-view'] = 'user';
$route['user-add'] = 'user/create';
$route['user-edit/(:any)'] = 'user/edit';

//  Access Route
$route['access-view'] = 'access';
$route['access-add'] = 'access/create';
$route['access-edit/(:any)'] = 'access/edit';