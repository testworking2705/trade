<?php

$config = array(
        'login' => array(
                array(
                        'field' => 'username',
                        'label' => 'Username',
                        'rules' => 'required'
                ),
                array(
                        'field' => 'password',
                        'label' => 'Password',
                        'rules' => 'required|min_length[8]|max_length[15]',
                                
                )                                
        ),
        'reset' => array(
                array(
                    'field' => 'email',
                    'label' => 'Email',
                    'errors' => array(
                            'required' => 'Please Enter valid %s',
                            'valid_email' => 'Please Enter valid email '
                            ),
                    'rules' => 'required|trim|valid_email'
                ),
                                
        ),
        'passwordset' => array(
                array(
                        'field' => 'password',
                        'label' => 'Password',
                        'errors' => array(
                                'required' => 'Please Enter Valid %s',
                                // 'valid_email' => 'Please Enter valid Password'
                                ),
                        'rules' => 'required|trim'
                ),
                array(
                        'field' => 'cpassword',
                        'label' => 'Confirm Password',
                        'errors' => array(
                                'required' => 'Please Confirm %s',
                                // 'valid_email' => 'Please Enter valid Confirm %s'
                                ),
                        'rules' => 'required|trim|matches[password]'
                ),
                                
        ),
        'contract' => array(
                
                /*
                array(
                        'field' => 'password',
                        'label' => 'Password',
                        'errors' => array(
                                'required' => 'Please Enter password %s',
                                'min_length' => '{field} must have at least {param} characters.',
                                'max_length' => '{field} must have at least {param} characters.'

                                ),
                        'rules' => 'required|trim|min_length[8]|max_length[15]'
                ),*/
                array(
                        'field' => 'contract_name',
                        'label' => 'Contract Name',
                        'errors' => array(
                                'required' => 'Please Enter %s '
                                ),
                                
                        'rules' => 'trim|required'
                ),

                
                array(
                        'field' => 'code',
                        'label' => 'Code',
                        'errors' => array(
                                'required' => 'Please Enter %s'
                                ),
                                
                        'rules' => 'trim|required'
                ),
                array(
                        'field' => 'tick_size',
                        'label' => 'Tick Size',
                        'errors' => array(
                                'trim|required' => 'Please Enter %s'
                                ),
                                
                        'rules' => 'trim|required'
                ),
                array(
                        'field' => 'tick_value',
                        'label' => 'Tick Value',
                        'errors' => array(
                                'required' => 'Please Enter %s'
                                ),
                                
                        'rules' => 'trim|required'
                ),
                array(
                        'field' => 'contract_margin',
                        'label' => 'Contract Margin',
                        'errors' => array(
                                'required' => 'Please Enter %s'
                                ),
                                
                        'rules' => 'trim|required'
                ),
                array(
                        'field' => 'contract_cycle',
                        'label' => 'Contract Cycle',
                        'errors' => array(
                                'required' => 'Please Enter %s'

                                ),
                                
                        'rules' => 'trim|required'
                ),
                array(
                        'field' => 'currency',
                        'label' => 'Currency',
                        'errors' => array(
                                'required' => 'Please Currency gender',
                                'check_default' => 'Please Currency gender'
                                ),
                        'rules' => 'required|trim|callback_check_default'
                )/*,
                array(
                        'field' => 'height',
                        'label' => 'Number or decimal',
                        'errors' => array(
                                'required' => 'Please Enter %s',
                                'max_length' => '{field} must have {param} characters.',
                                'numeric' => '{field} must have {param} characters.',
                                'decimal' => '{field} must have {param} characters.',
                                ),
                                
                        'rules' => 'required|max_length[5]|numeric|decimal'
                ),
                array(
                        'field' => 'education',
                        'label' => 'Education',
                        'errors' => array(
                                'required' => 'Please Enter Your %s',
                                 
                                ),
                                
                        'rules' => 'required'
                ),
                array(
                        'field' => 'job_yes_no',
                        'label' => 'Working or Not',
                        'errors' => array(
                                'required' => 'Please Select Job Status',
                                'check_default' => 'Please Select Job Status'
                                ),
                        'rules' => 'required|trim|callback_check_default'
                ),*/

                /*array(
                        'field' => 'jobs',
                        'label' => 'Job Description',
                        'errors' => array(
                                'required' => 'Please Enter Your %s'
                                // 'check_default' => 'Please Select Job Status'
                                ),
                        'rules' => 'required|trim'
                ),
                array(
                        'field' => 'monthly_income',
                        'label' => 'Monthly Income',
                        'errors' => array(
                                'required' => 'Please Enter Your %s'
                                // 'check_default' => 'Please Select Job Status'
                                ),
                        'rules' => 'required|trim'
                ),*/
                
                
                
               /* array(
                        'field' => 'email',
                        'label' => 'Email',
                        'errors' => array(
                                'required' => 'Please Enter valid Email %s',
                                'is_unique' => 'this email Already register'
                                ),
                        'rules' => 'trim|valid_email|is_unique[candidates.email]'
                ),
                array(
                        'field' => 'mobile',
                        'label' => 'mobile',
                        'errors' => array(
                                'required' => 'Please Enter valid Mobile No %s',
                                'exact_length' => '{field} must have at least {param} Digit.',
                                'integer' => 'Please Enter 10 Digit Valid Mobile No' 
                                ),
                        'rules' => 'required|exact_length[10]|numeric|is_unique[candidates.mobile]',
                )*/
        ),
        'client' => array(
                
                /*
                array(
                        'field' => 'password',
                        'label' => 'Password',
                        'errors' => array(
                                'required' => 'Please Enter password %s',
                                'min_length' => '{field} must have at least {param} characters.',
                                'max_length' => '{field} must have at least {param} characters.'

                                ),
                        'rules' => 'required|trim|min_length[8]|max_length[15]'
                ),*/
                array(
                        'field' => 'client_id',
                        'label' => 'Client Id',
                        'errors' => array(
                                'required' => 'Please Enter %s '
                                ),
                                
                        'rules' => 'trim|required'
                ),

                
                array(
                        'field' => 'first_name',
                        'label' => 'First Name',
                        'errors' => array(
                                'required' => 'Please Enter %s'
                                ),
                                
                        'rules' => 'trim|required'
                ),
                array(
                        'field' => 'last_name',
                        'label' => 'Last Name',
                        'errors' => array(
                                'required' => 'Please Enter %s'
                                ),
                                
                         'rules' => 'trim|required'
                ),
                array(
                        'field' => 'company_associate',
                        'label' => 'Company Associated',
                        'errors' => array(
                                'required' => 'Please Enter %s'
                                ),
                                
                        'rules' => 'trim|required'
                ),
                array(
                        'field' => 'c_id',
                        'label' => 'M ID',
                        'errors' => array(
                                'required' => 'Please Enter %s',
                                 'exact_length' => '{field} must have {param} Digit.',
                                 'numeric' => '{field} must have {param} characters.',

                                ),
                                
                        'rules' => 'trim|required|exact_length[10]|numeric'
                ),
                array(
                         'field' => 'subscription',
                        'label' => 'Subscription',
                        'errors' => array(
                                'required' => 'Please Enter %s'

                                ),
                                
                        'rules' => 'trim|required'
                )
                /*array(
                        'field' => 'subscription',
                        'label' => 'Subscription',
                        'errors' => array(
                                'required' => 'Please Currency gender',
                                'check_default' => 'Please Currency gender'
                                ),
                        'rules' => 'required|trim|callback_check_default'
                )*/,
                array(
                        'field' => 'market_data',
                        'label' => 'Market Data',
                        'errors' => array(
                                'required' => 'Please Enter %s',
                                'max_length' => '{field} must have {param} characters.',
                                'numeric' => '{field} must have {param} characters.',
                                ),
                                
                        'rules' => 'required|max_length[8]|numeric'
                ),
                array(
                        'field' => 'admin_fee',
                        'label' => 'Admin Fee',
                        'errors' => array(
                                'required' => 'Please Enter %s',
                                'max_length' => '{field} must have {param} characters.',
                                'numeric' => '{field} must have {param} characters.',
                                ),
                                
                        'rules' => 'required|max_length[8]|numeric'
                ),
                array(
                        'field' => 'others',
                        'label' => 'Other',
                        'errors' => array(
                                'required' => 'Please Enter %s',
                                'max_length' => '{field} must have {param} characters.',
                                'numeric' => '{field} must have {param} characters.',
                                ),
                                
                        'rules' => 'required|max_length[8]|numeric'
                ),
                array(
                        'field' => 'commision',
                        'label' => 'Commision',
                        'errors' => array(
                                'required' => 'Please Enter %s',
                                'max_length' => '{field} must have {param} characters.',
                                //'numeric' => '{field} must have {param} characters.',
                                'decimal' => '{field} must have {param} characters.',
                                ),
                                
                        'rules' => 'required|max_length[8]|decimal'
                ),
                array(
                        'field' => 'clearingfee',
                        'label' => 'Clearing fee',
                        'errors' => array(
                                'required' => 'Please Enter %s',
                                'max_length' => '{field} must have {param} characters.',
                                'decimal' => '{field} must have {param} characters.',
                                 
                                ),
                                
                        'rules' => 'required|max_length[8]|decimal'
                ),
                array(
                        'field' => 'exchangefee',
                        'label' => 'Exchange fee',
                        'errors' => array(
                                'required' => 'Please Enter %s',
                                'max_length' => '{field} must have {param} characters.',
                               
                                'decimal' => '{field} must have {param} characters.',
                                ),
                                
                        'rules' => 'required|max_length[8]|decimal'
                ),
                array(
                        'field' => 'transationalfee',
                        'label' => 'Transational fee',
                        'errors' => array(
                                'required' => 'Please Enter %s',
                                'max_length' => '{field} must have {param} characters.',
                                'decimal' => '{field} must have {param} characters.',
                                ),
                                
                        'rules' => 'required|max_length[8]|decimal'
                ),
                array(
                        'field' => 'nfa',
                        'label' => 'NFA',
                        'errors' => array(
                                'required' => 'Please Enter %s',
                                'max_length' => '{field} must have {param} characters.',
                                'decimal' => '{field} must have {param} characters.',
                                ),
                                
                        'rules' => 'required|max_length[8]|decimal'
                )
                 

                
                
                
               /* array(
                        'field' => 'email',
                        'label' => 'Email',
                        'errors' => array(
                                'required' => 'Please Enter valid Email %s',
                                'is_unique' => 'this email Already register'
                                ),
                        'rules' => 'trim|valid_email|is_unique[candidates.email]'
                ),
                array(
                        'field' => 'mobile',
                        'label' => 'mobile',
                        'errors' => array(
                                'required' => 'Please Enter valid Mobile No %s',
                                'exact_length' => '{field} must have at least {param} Digit.',
                                'integer' => 'Please Enter 10 Digit Valid Mobile No' 
                                ),
                        'rules' => 'required|exact_length[10]|numeric|is_unique[candidates.mobile]',
                )*/
        ),
        'company' => array(
            array(
                'field' => 'client_id',
                'label' => 'Client Id',
                'errors' => array(
                        'required' => 'Please Enter %s '
                        ),
                        
                'rules' => 'trim|required'
            ),     
            array(
                'field' => 'first_name',
                'label' => 'First Name',
                'errors' => array(
                        'required' => 'Please Enter %s'
                        ),
                        
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'last_name',
                'label' => 'Last Name',
                'errors' => array(
                        'required' => 'Please Enter %s'
                        ),
                        
                 'rules' => 'trim|required'
            ),
           /* array(
                'field' => 'company_associate',
                'label' => 'Company Associated',
                'errors' => array(
                        'required' => 'Please Enter %s'
                        ),
                        
                'rules' => 'trim|required'
            ),*/
            array(
                'field' => 'c_id',
                'label' => 'M ID',
                'errors' => array(
                        'required' => 'Please Enter %s',
                         'exact_length' => '{field} must have {param} Digit.',
                         'numeric' => '{field} must have {param} characters.',

                        ),
                        
                'rules' => 'trim|required|exact_length[10]|numeric'
            ),
            array(
                'field' => 'subscription',
                'label' => 'Subscription',
                'errors' => array(
                        'required' => 'Please Enter %s'

                        ),
                        
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'market_data',
                'label' => 'Market Data',
                'errors' => array(
                        'required' => 'Please Enter %s',
                        'max_length' => '{field} must have {param} characters.',
                        'numeric' => '{field} must have {param} characters.',
                        ),
                        
                'rules' => 'required|max_length[7]|numeric'
            ),
            array(
                'field' => 'admin_fee',
                'label' => 'Admin Fee',
                'errors' => array(
                        'required' => 'Please Enter %s',
                        'max_length' => '{field} must have {param} characters.',
                        'numeric' => '{field} must have {param} characters.',
                        ),
                        
                'rules' => 'required|max_length[7]|numeric'
            ),
            /*array(
                'field' => 'others',
                'label' => 'Other',
                'errors' => array(
                        'required' => 'Please Enter %s',
                        'max_length' => '{field} must have {param} characters.',
                        'numeric' => '{field} must have {param} characters.',
                        ),
                        
                'rules' => 'required|max_length[5]|numeric'
            ),*/
            array(
                'field' => 'commision',
                'label' => 'Commision',
                'errors' => array(
                        'required' => 'Please Enter %s',
                        'max_length' => '{field} must have {param} characters.',
                        //'numeric' => '{field} must have {param} characters.',
                        'decimal' => '{field} must have {param} characters.',
                        ),
                        
                'rules' => 'required|max_length[7]|decimal'
            ),
            array(
                'field' => 'clearingfee',
                'label' => 'Clearing fee',
                'errors' => array(
                        'required' => 'Please Enter %s',
                        'max_length' => '{field} must have {param} characters.',
                        'decimal' => '{field} must have {param} characters.',
                         
                        ),
                        
                'rules' => 'required|max_length[7]|decimal'
            ),
            array(
                'field' => 'exchangefee',
                'label' => 'Exchange fee',
                'errors' => array(
                        'required' => 'Please Enter %s',
                        'max_length' => '{field} must have {param} characters.',
                       
                        'decimal' => '{field} must have {param} characters.',
                        ),
                        
                'rules' => 'required|max_length[7]|decimal'
            ),
            array(
                'field' => 'transationalfee',
                'label' => 'Transational fee',
                'errors' => array(
                        'required' => 'Please Enter %s',
                        'max_length' => '{field} must have {param} characters.',
                        'decimal' => '{field} must have {param} characters.',
                        ),
                        
                'rules' => 'required|max_length[7]|decimal'
            ),
            array(
                'field' => 'nfa',
                'label' => 'NFA',
                'errors' => array(
                        'required' => 'Please Enter %s',
                        'max_length' => '{field} must have {param} characters.',
                        'decimal' => '{field} must have {param} characters.',
                        ),
                        
                'rules' => 'required|max_length[7]|decimal'
            )
        ),    
        'singup' => array(
                
                
                array(
                        'field' => 'password',
                        'label' => 'Password',
                        'errors' => array(
                                'required' => 'Please Enter password %s',
                                'min_length' => '{field} must have at least {param} characters.',
                                'max_length' => '{field} must have at least {param} characters.'

                                ),
                        'rules' => 'required|trim|min_length[7]|max_length[15]'
                ),
                array(
                        'field' => 'name',
                        'label' => 'You Full name',
                        'errors' => array(
                                'required' => 'Please Enter User Full Name'
                                ),
                                
                        'rules' => 'required'
                ),
                array(
                        'field' => 'email',
                        'label' => 'Email',
                        'errors' => array(
                                //'required' => 'Please Enter valid Email %s',
                                'is_unique' => 'this email Already register'
                                ),
                        'rules' => 'trim|valid_email|is_unique[login_user.email]'
                ),
                array(
                        'field' => 'mobile',
                        'label' => 'mobile',
                        'errors' => array(
                                'required' => 'Please Enter valid Mobile No %s',
                                'exact_length' => '{field} must have at least {param} Digit.',
                                'integer' => 'Please Enter 10 Digit Valid Mobile No' 
                                ),
                        'rules' => 'required|exact_length[10]|numeric|is_unique[login_user.mobile]',
                )
        ),

        'user' => array(
            array(
                'field' => 'email',
                'label' => 'Email',
                'errors' => array(
                        'required' => 'Enter %s',
                        'is_unique' => 'this email Already register',
                        'valid_email' => 'Enter Valid Email Address'
                        ),
                'rules' => 'required|trim|valid_email|is_unique[users.email]'
            ),
            array(
                'field' => 'password',
                'label' => 'Password',
                'errors' => array(
                        'required' => 'Please Enter %s',
                        'min_length' => '{field} must have at least {param} characters.',
                        'max_length' => '{field} must have at least {param} characters.'

                        ),
                'rules' => 'required|trim|min_length[8]|max_length[15]'
            ), 
            array(
                'field' => 'mobile',
                'label' => 'Mobile',
                'errors' => array(
                        'required' => 'Please Enter %s',
                        'exact_length' => '{field} must have at least {param} characters.'

                        ),
                'rules' => 'required|trim|exact_length[10]'
            ),
            array(
                'field' => 'name',
                'label' => 'You Full name',
                'errors' => array(
                        'required' => 'Enter %s'
                        ),
                        
                'rules' => 'required|trim'
            ),
             
            array(
                'field' => 'roles',
                'label' => 'Select Role',
                'errors' => array(
                        'required' => 'Please Select Role',
                        'check_default' => 'Please Your Select Role'
                        ),
                'rules' => 'required|trim|callback_check_default'
            )
                 
        ),
        'user_up' => array(
            array(
                'field' => 'email',
                'label' => 'Email',
                'errors' => array(
                        'required' => 'Enter %s',
                        'is_unique' => 'this email Already register',
                        'valid_email' => 'Enter Valid Email Address'
                        ),
                'rules' => 'required|trim|valid_email'
            ),
            /*array(
                'field' => 'password',
                'label' => 'Password',
                'errors' => array(
                        'required' => 'Please Enter %s',
                        'min_length' => '{field} must have at least {param} characters.',
                        'max_length' => '{field} must have at least {param} characters.'

                        ),
                'rules' => 'required|trim|min_length[8]|max_length[15]'
            ),*/ 
            array(
                'field' => 'mobile',
                'label' => 'Mobile',
                'errors' => array(
                        'required' => 'Please Enter %s',
                        'exact_length' => '{field} must have at least {param} characters.'

                        ),
                'rules' => 'required|trim|exact_length[10]'
            ),
            array(
                'field' => 'name',
                'label' => 'You Full name',
                'errors' => array(
                        'required' => 'Enter %s'
                        ),
                        
                'rules' => 'required|trim'
            ),
             
            array(
                'field' => 'roles',
                'label' => 'Select Role',
                'errors' => array(
                        'required' => 'Please Select Role',
                        'check_default' => 'Please Your Select Role'
                        ),
                'rules' => 'required|trim|callback_check_default'
            )
                 
        ),
        /*'login' => array(
                array(
                        'field' => 'email',
                        'label' => 'UserName',
                        'errors' => array(
                                'required' => 'Please Enter valid %s'
                                // 'valid_email' => 'Please Enter valid UserName  '
                                //'is_unique' => 'this email Already register'
                                ),
                        'rules' => 'required'
                ),
                array(
                        'field' => 'email',
                        'label' => 'Email',
                        'errors' => array(
                                'required' => 'Please Enter valid %s',
                                'valid_email' => 'Please Enter valid email '
                                //'is_unique' => 'this email Already register'
                                ),
                        'rules' => 'required|trim|valid_email'
                ),
                array(
                        'field' => 'password',
                        'label' => 'Password',
                        'errors' => array(
                                'required' => 'Please Enter password %s',
                                'min_length' => '{field} must have at least {param} characters.',
                                'max_length' => '{field} must have at least {param} characters.'

                                ),
                        'rules' => 'required|trim|min_length[8]|max_length[15]'
                ) 
        ),*/
        'society' => array(
                array(
                        'field' => 'selectzone',
                        'label' => 'Society Zone',
                        'errors' => array(
                                'required' => 'Please Select %s'
                                //'valid_email' => 'Please Enter valid email '
                                //'is_unique' => 'this email Already register'
                                ),
                        'rules' => 'required|trim'
                ),
                array(
                        'field' => 'name',
                        'label' => 'Society',
                        'errors' => array(
                                'required' => 'Please Enter %s Name'
                                /*'min_length' => '{field} must have at least {param} characters.',
                                'max_length' => '{field} must have at least {param} characters.'*/

                                ),
                        'rules' => 'required|trim'
                ) 
        ),
        'addboys' => array(
                /*array(
                        'field' => 'selectzone',
                        'label' => 'Society Zone',
                        'errors' => array(
                                'required' => 'Please Select %s'
                                //'valid_email' => 'Please Enter valid email '
                                //'is_unique' => 'this email Already register'
                                ),
                        'rules' => 'required|trim'
                ),*/
                
                array(
                        'field' => 'name',
                        'label' => 'Delivery Boy',
                        'errors' => array(
                                'required' => 'Please Enter %s Name'
                                /*'min_length' => '{field} must have at least {param} characters.',
                                'max_length' => '{field} must have at least {param} characters.'*/

                                ),
                        'rules' => 'required|trim'
                ),
                array(
                        'field' => 'mobile',
                        'label' => 'Mobile',
                        'errors' => array(
                                'required' => 'Please Enter valid Mobile No %s',
                                'exact_length' => '{field} Accept only {param} Digit Number.',
                                'integer' => 'Please Enter 10 Digit Valid Mobile No',
                                'is_unique' => 'This Mobile No Already Registerd.'
                                ),
                        'rules' => 'required|exact_length[10]|numeric|is_unique[dilivery_boys.mobile]',
                ),
                array(
                        'field' => 'address',
                        'label' => 'Address',
                        'errors' => array(
                                'required' => 'Please Enter %s'
                                /*'min_length' => '{field} must have at least {param} characters.',
                                'max_length' => '{field} must have at least {param} characters.'*/

                                ),
                        'rules' => 'required|trim'
                ) 
        ),
        'contact' => array(
                array(
                        'field' => 'email',
                        'label' => 'Email',
                        'errors' => array(
                                'required' => 'Please Enter valid %s',
                                'valid_email' => 'Please Enter valid email '
                                //'is_unique' => 'this email Already register'
                                ),
                        'rules' => 'required|trim|valid_email'
                ),
                array(
                        'field' => 'name',
                        'label' => 'Name',
                        'errors' => array(
                                'required' => 'Please Enter Your %s',
                                //'min_length' => '{field} must have at least {param} characters.',
                                //'max_length' => '{field} must have at least {param} characters.'

                                ),
                        'rules' => 'required|trim'
                ),
                array(
                        'field' => 'mobile',
                        'label' => 'Mobile',
                        'errors' => array(
                                'required' => 'Please Enter valid Mobile No %s',
                                'exact_length' => '{field} Accept only {param} Digit Number.',
                                'integer' => 'Please Enter 10 Digit Valid Mobile No' 
                                ),
                        'rules' => 'required|exact_length[10]|numeric',
                ),
                array(
                        'field' => 'message',
                        'label' => 'message',
                        'errors' => array(
                                'max_length' => '{field} must have at least {param} characters.'
                                ),
                        'rules' => 'max_length[200]',
                ) 
        ),
        'veriant' => array(
                array(
                        'field' => 'veriantname',
                        'label' => 'Veriant',
                        'errors' => array(
                                'required' => 'Please Enter %s Name',
                                //'valid_email' => 'Please Enter valid email '
                                //'is_unique' => 'this email Already register'
                                ),
                        'rules' => 'required|trim'
                )
        ),
        'zones' => array(
                array(
                        'field' => 'zonename',
                        'label' => 'Zone',
                        'errors' => array(
                                'required' => 'Please Enter %s Name',
                                //'valid_email' => 'Please Enter valid email '
                                //'is_unique' => 'this email Already register'
                                ),
                        'rules' => 'required|trim'
                )
        ),
        'product' => array(
                array(
                        'field' => 'name',
                        'label' => 'Product',
                        'errors' => array(
                                'required' => 'Please Enter %s Name',
                                //'valid_email' => 'Please Enter valid email '
                                //'is_unique' => 'this email Already register'
                                ),
                        'rules' => 'required|trim'
                ),
                 
                
                array(
                        'field' => 'desc',
                        'label' => 'Description',
                        'errors' => array(
                                'required' => 'Please Enter %s ',
                                //'valid_email' => 'Please Enter valid email '
                                //'is_unique' => 'this email Already register'
                                ),
                        'rules' => 'required|trim'
                )
                /*array(
                        'field' => 'category_id',
                        'label' => 'Category',
                        'errors' => array(
                                'required' => 'Please Select %s ',
                                //'valid_email' => 'Please Enter valid email '
                                //'is_unique' => 'this email Already register'
                                ),
                        'rules' => 'required|trim'
                ),
                array(
                        'field' => 'product_type_id',
                        'label' => 'Product Type',
                        'errors' => array(
                                'required' => 'Please Select %s',
                                //'valid_email' => 'Please Enter valid email '
                                //'is_unique' => 'this email Already register'
                                ),
                        'rules' => 'required|trim'
                )*/
        ),
        'category' => array(
                array(
                        'field' => 'name',
                        'label' => 'Category',
                        'errors' => array(
                                'required' => 'Please Enter %s Name',
                                //'valid_email' => 'Please Enter valid email '
                                //'is_unique' => 'this email Already register'
                                ),
                        'rules' => 'required|trim'
                )
        ),
        'subcategory' => array(
                array(
                        'field' => 'category_id',
                        'label' => 'Category',
                        'errors' => array(
                                'required' => 'Please Select %s Name',
                                //'valid_email' => 'Please Enter valid email '
                                //'is_unique' => 'this email Already register'
                                ),
                        'rules' => 'required|trim'
                ),
                array(
                        'field' => 'name',
                        'label' => 'Sub Category',
                        'errors' => array(
                                'required' => 'Please Enter %s Name',
                                //'valid_email' => 'Please Enter valid email '
                                //'is_unique' => 'this email Already register'
                                ),
                        'rules' => 'required|trim'
                )
        ),
        'profile_update' => array(
                 
                array(
                        'field' => 'name',
                        'label' => 'Name',
                        'errors' => array(
                                'required' => 'Please Enter Your %s',
                                //'min_length' => '{field} must have at least {param} characters.',
                                //'max_length' => '{field} must have at least {param} characters.'

                                ),
                        'rules' => 'required|trim'
                ),
                array(
                        'field' => 'mobile',
                        'label' => 'Mobile',
                        'errors' => array(
                                'required' => 'Please Enter valid Mobile No %s',
                                'exact_length' => '{field} Accept only {param} Digit Number.',
                                'integer' => 'Please Enter 10 Digit Valid Mobile No' 
                                ),
                        'rules' => 'required|exact_length[10]|numeric',
                )
                
        ),


        'eventimagevalidation' => array(
                array(
                        'field' => 'eventslist',
                        'label' => 'Events',
                        'errors' => array(
                                'required' => 'Please Select Events Name ',
                                'check_default' => 'Please Select Any One Event'
                                ),
                        'rules' => 'required|trim|callback_check_default'
                )
        ),
        'addEvent' => array(
                array(
                        'field' => 'eventname',
                        'label' => 'Event',
                        'errors' => array(
                                'required' => 'Please Enter %s Name',
                                //'valid_email' => 'Please Enter valid email '
                                //'is_unique' => 'this email Already register'
                                ),
                        'rules' => 'required|trim'
                ),
                array(
                        'field' => 'datepicker',
                        'label' => 'Date',
                        'errors' => array(
                                'required' => 'Please Enter Event %s ',
                                //'valid_email' => 'Please Enter valid email '
                                //'is_unique' => 'this email Already register'
                                ),
                        'rules' => 'required|trim'
                )
        ),
        'franchise' => array(
                array(
                        'field' => 'mobile',
                        'label' => 'Mobile',
                        'errors' => array(
                                'required' => 'Please Enter %s Name',
                                'numeric' => 'Please Enter valid 10 Digit Number '
                                //'is_unique' => 'this email Already register'
                                ),
                        'rules' => 'required|trim|numeric'
                ),
                array(
                        'field' => 'email',
                        'label' => 'Email',
                        'errors' => array(
                                'required' => 'Please Enter valid %s',
                                'valid_email' => 'Please Enter valid email '
                                ),
                        'rules' => 'required|trim|valid_email'
                )
        )
);

?>