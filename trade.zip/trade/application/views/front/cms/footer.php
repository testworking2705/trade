<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0
    </div>
    <strong>Copyright &copy; 1997 - 2020 <a href="#">Alliance infotech Pvt. Ltd</a>.</strong> All rights
    reserved.
  </footer>