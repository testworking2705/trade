<!-- jQuery 3 -->
<script src="<?=BASEURL?>assets/bower_components/jquery/dist/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?=BASEURL?>assets/bower_components/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 3.3.7 -->
<script src="<?=BASEURL?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

<!-- Select2 -->
<script src="<?=BASEURL?>assets/bower_components/select2/dist/js/select2.full.min.js"></script>


<!-- Morris.js charts -->
<script src="<?=BASEURL?>assets/bower_components/raphael/raphael.min.js"></script>
<script src="<?=BASEURL?>assets/bower_components/morris.js/morris.min.js"></script>
<!-- Sparkline -->
<script src="<?=BASEURL?>assets/bower_components/jquery-sparkline/dist/jquery.sparkline.min.js"></script>
<!-- jvectormap -->
<script src="<?=BASEURL?>assets/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="<?=BASEURL?>assets/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<!-- jQuery Knob Chart -->
<script src="<?=BASEURL?>assets/bower_components/jquery-knob/dist/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="<?=BASEURL?>assets/bower_components/moment/min/moment.min.js"></script>
<script src="<?=BASEURL?>assets/bower_components/bootstrap-daterangepicker/daterangepicker.js"></script>
<!-- datepicker -->
<script src="<?=BASEURL?>assets/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="<?=BASEURL?>assets/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<!-- Slimscroll -->
<script src="<?=BASEURL?>assets/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- iCheck 1.0.1 -->
<script src="<?=BASEURL?>assets/plugins/iCheck/icheck.min.js"></script>
<!-- FastClick -->
<script src="<?=BASEURL?>assets/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?=BASEURL?>assets/dist/js/adminlte.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<!-- <script src="<?=BASEURL?>assets/dist/js/pages/dashboard.js"></script> -->
<!-- AdminLTE for demo purposes -->
<script src="<?=BASEURL?>assets/dist/js/demo.js"></script>



<script>
  //  function getTradeID(trade_id, name) {
  //   console.log("trade_id " +trade_id);
  //   console.log("name " +name);
  //   $("#tradeId").val(trade_id+"_"+name);
  // }


  $(function () {



    $('input[name="trades"]').on("click", function(e) {
      console.log('OK WORKING 3 ');
      var tradeId = $(this).attr('id') ;
        $("#tradeId").val(tradeId);
        // if (e.clientX === 0 && e.clientY === 0) {
        //     console.log("keyboard");
        // } else {
        //     console.log("mouse");
        // };
    });


    //Initialize Select2 Elements
     $('.select2').select2()

   /* //Datemask dd/mm/yyyy
    $('#datemask').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' })
    //Datemask2 mm/dd/yyyy
    $('#datemask2').inputmask('mm/dd/yyyy', { 'placeholder': 'mm/dd/yyyy' })
    //Money Euro
    $('[data-mask]').inputmask()

    //Date range picker
    $('#reservation').daterangepicker()
    //Date range picker with time picker
    $('#reservationtime').daterangepicker({ timePicker: true, timePickerIncrement: 30, locale: { format: 'MM/DD/YYYY hh:mm A' }})
    //Date range as a button
    $('#daterange-btn').daterangepicker(
      {
        ranges   : {
          'Today'       : [moment(), moment()],
          'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
          'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
          'Last 30 Days': [moment().subtract(29, 'days'), moment()],
          'This Month'  : [moment().startOf('month'), moment().endOf('month')],
          'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        },
        startDate: moment().subtract(29, 'days'),
        endDate  : moment()
      },
      function (start, end) {
        $('#daterange-btn span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
      }
    )*/

    //Date picker
    $('#from').datepicker({
      autoclose: true,
      format :'dd-mm-yyyy'
    })
    $('#to').datepicker({
      autoclose: true,
      format :'dd-mm-yyyy'
    })


    //iCheck for checkbox and radio inputs
    $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
      checkboxClass: 'icheckbox_minimal-blue',
      radioClass   : 'iradio_minimal-blue'
    })
    //Red color scheme for iCheck
    $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
      checkboxClass: 'icheckbox_minimal-red',
      radioClass   : 'iradio_minimal-red'
    })
    //Flat red color scheme for iCheck
    $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
      checkboxClass: 'icheckbox_flat-green',
      radioClass   : 'iradio_flat-green'
    })

    /*//Colorpicker
    $('.my-colorpicker1').colorpicker()
    //color picker with addon
    $('.my-colorpicker2').colorpicker()

    //Timepicker
    $('.timepicker').timepicker({
      showInputs: false
    })*/
  });


  function deleteRow(id, filename) {

    if (confirm('Are you sure to remove')) {
      var tid='' ;
      $('#example1 tr').click(function(event) {
        tid = $(this).attr('id');
        console.log( ' tid '+ tid );
      });
        console.log("tid " + tid);
     
        $.ajax({
            url: '<?php echo base_url(); ?>Welcome/DeleteRecords',
            type: 'POST',
            data: {id: id, filename : filename},
            success: function (data) {
              var obj = JSON.parse(data) ;
                if (obj.error == false) {

                  $("#message").text(obj.message).css('color', 'green');
                  
                  if($('#' + tid).length) {
                    $('#' + tid).remove();
                  }

                  setTimeout(function(){
                    window.location.reload(true);
                  },2000);
                } else {
                  $("#message").text(data.message).css('color', 'red');return false;
                    //window.location.reload(true);


                    //successMsg(data.message);

                }
            }
        });
    }
}


/*$( function () {

  $("#set_user_access").on('submit', function(e){
    e.preventDefault();
    console.log('HERE');
    var fdata = $("#set_user_access").serialize();
    //$("#adduseraccess").prop('disabled', true).text('please Wait...');
    
    $.ajax({
      url: '<?php echo site_url('Access/addAccessToUsers'); ?>',
      type: 'POST',
      data: fdata,
      success: function (data) {
        //$("#adduseraccess").prop('disabled', false).text('Add');
        console.log(data);
        var obj = JSON.parse(data) ;
        console.log(obj);
        console.log('message '  + obj.message);

          if (obj.error == false) {
            $("#response").text(obj.message).css('color', 'green');
            setTimeout(function(){
              window.location.reload(true);
            },2000);
          } 
          else {
            $("#response").text(obj.message).css('color', 'red').css('font-size' , '16px');return false;
              //window.location.reload(true);
              //successMsg(data.message);
          }
      },
      fail:function (data) {
        //$("#adduseraccess").prop('disabled', false).text('Add');
      },
      always : function(data){
        //$("#adduseraccess").prop('disabled', false).text('Add');
      }

    });
  });
});*/

 
</script>

</body>
</html>
