<?php $this->load->view('front/cms/head')?>

<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">

  <?php $this->load->view('front/cms/header')?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('front/cms/sidebar')?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?=$title?>
        <!-- <small>Control panel</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><?=$pageheader?></li>
      </ol>
    </section>

    <!-- Main content -->
     <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title"><?=$pageheader?></h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
           <?php $this->load->view('pages/response')?>




            <form role="form" id="app_contract" method="post" action="<?=site_url('contract-edit/'.$id)?>" enctype="multipart/form-data" >
              <input type="hidden" name="contract_id" value="<?=$id?>">
              <div class="box-body">
                  
              <div class="row">  
                <div class="col-md-6">
                <div class="form-group">
                  <label for="name">Contract Name</label> <span style="color: red"> *</span>
                  <input type="text" class="form-control" id="contract_name" name="contract_name" value="<?= set_value('contract_name', $contract_info->contract_name ) ?>" maxlength="100" placeholder="Contract Name">
                   <?= form_error('contract_name')?>
                </div>
                </div>

                <div class="col-md-3">
                <div class="form-group">
                  <label for="code1">Code</label><span style="color: red"> *</span>
                  <input type="text" class="form-control" id="code" name="code" maxlength="100" value="<?= set_value('code', $contract_info->code) ?>" placeholder="Enter Contract Code">
                  <?= form_error('code')?>
                </div>
              </div>

              <!-- <div class="col-md-3">
                <div class="form-group">
                  <label for="code2">Code2</label><span style="color: red"> *</span>
                  <input type="text" class="form-control" id="code2" name="code2" value="<?= set_value('code2') ?>"  maxlength="100" placeholder="Enter Contract Code">
                  <?= form_error('code2')?>
                </div>
              </div> -->
              </div>


               <div class="row"> 
              <div class="col-md-3">
                <div class="form-group">
                  <label for="tick_size">Tick Size</label><span style="color: red"> *</span>
                  <input type="text" class="form-control" id="tick_size" value="<?= set_value('tick_size', $contract_info->tick_size) ?>" name="tick_size" maxlength="5" placeholder="Enter Tick Size">
                  <?= form_error('tick_size')?>
                </div>
              </div>

               <div class="col-md-3">
                <div class="form-group">
                  <label for="tick_value">Tick Value</label><span style="color: red"> *</span>
                  <input type="text" class="form-control" id="tick_value" name="tick_value" value="<?= set_value('tick_value', $contract_info->tick_value) ?>" maxlength="5" placeholder="Enter Tick Value">
                  <?= form_error('tick_value')?>
                </div>
              </div>

               <div class="col-md-3">
                <div class="form-group">
                  <label for="contract_cycle">Contract Cycle</label><span style="color: red"> *</span>
                  <input type="text" class="form-control" id="contract_cycle" value="<?= set_value('contract_cycle', $contract_info->contract_cycle) ?>" name="contract_cycle" maxlength="100" placeholder="Enter Contrat Cycle ">
                  <?= form_error('contract_cycle')?>
                </div>
              </div>

               <div class="col-md-3">
                <div class="form-group">
                  <label for="currency">Currency</label><span style="color: red"> *</span>
                  <select class="form-control" name="currency" >
                    <option value="0">--Select Currency--</option>
                    <?php foreach($currency as $key => $value):?>
                    <?php if($contract_info->currency == $value->currency_code):?>
                      <option selected="selected" value="<?=$value->id?>" > <?=$value->currency_code?></option>
                    <?php else:?>
                      <option value="<?=$value->currency_code?>"><?=$value->currency_code?></option>
                    <?php endif;?>

                    <?php endforeach;?>
                  </select>
                  <?= form_error('currency')?>
                  
                </div>
                 </div>
              </div>   

              
               <div class="row"> 

                <div class="col-md-3">
                <div class="form-group">
                  <label for="first_cycle">First Notice</label><!-- <span style="color: red"> *</span> -->
                  <input type="text" class="form-control" id="first_cycle" value="<?= set_value('first_cycle') ?>" name="first_cycle" maxlength="100" placeholder="Enter First Notice ">
                  <?= form_error('first_cycle')?>
                </div>
              </div>

              <div class="col-md-3">
                <div class="form-group">
                  <label for="expiry">Expiry</label><!-- <span style="color: red"> *</span> -->
                  <input type="text" class="form-control" id="expiry" name="expiry" value="<?= set_value('expiry') ?>" maxlength="100" placeholder="Enter Expiry">
                  <?= form_error('expiry')?>
                </div>
              </div>
            </div>
                 
              </div>
              <!-- /.box-body -->

              <div class="box-footer text-right">
                <button type="submit" class="btn btn-primary ">Update Contract</button>
              </div>
            </form>
          </div>
          <!-- /.box -->

          

        </div>
        <!--/.col (left) -->
        <!-- right column -->
        <!-- <div class="col-md-6"> -->
          <!-- Horizontal Form -->
          
          <!-- /.box -->
          <!-- general form elements disabled -->
           
          <!-- /.box -->
        <!-- </div> -->
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php $this->load->view('front/cms/footer') ?>

  <!-- Control Sidebar -->
  <?php $this->load->view('front/cms/rightsight') ?>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->
<?php $this->load->view('front/cms/js') ?>

