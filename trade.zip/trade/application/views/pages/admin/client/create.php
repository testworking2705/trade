<?php $this->load->view('front/cms/head')?>

<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">

  <?php $this->load->view('front/cms/header')?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('front/cms/sidebar')?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?=$title?>
        <!-- <small>Control panel</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><?=$pageheader?></li>
      </ol>
    </section>

    <!-- Main content -->
     <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title"><?=$pageheader?></h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <?php $this->load->view('pages/response')?>


            <form role="form" id="app_contract" method="post" action="<?=site_url('client-add')?>" enctype="multipart/form-data" >
              
              <div class="box-body">
                  
              <div class="row">  
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="name">Client ID</label> <span style="color: red"> *</span>
                    <input type="text" class="form-control" id="client_id" name="client_id" value="<?= set_value('client_id') ?>" maxlength="100" placeholder="Enter Clinet ID">
                     <?= form_error('client_id')?>
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <label for="first_name">First Name</label><span style="color: red"> *</span>
                    <input type="text" class="form-control" id="first_name" name="first_name" maxlength="100" value="<?= set_value('first_name') ?>" placeholder="Enter First Name">
                    <?= form_error('first_name')?>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="last_name">Last Name</label><span style="color: red"> *</span>
                    <input type="text" class="form-control" id="last_name" name="last_name" maxlength="100" value="<?= set_value('last_name') ?>" placeholder="Enter Last Name">
                    <?= form_error('last_name')?>
                  </div>
                </div>

                <div class="col-md-3">
                    <div class="form-group">
                      <label for="company_associate">Company Associated</label><span style="color: red"> *</span>
                      <input type="text" class="form-control" id="company_associate" name="company_associate" value="<?= set_value('company_associate') ?>"  maxlength="100" placeholder="Company Associated With">
                      <?= form_error('company_associate')?>
                    </div>
                  </div>
                </div>


              <h4><b>Fixed Cost</b></h4> 
              <div class="row">
                <div class="col-md-2">
                  <div class="form-group">
                    <label for="c_id">M ID</label><span style="color: red"> *</span>
                    <input  type="number" class="form-control" id="c_id" value="<?= set_value('c_id') ?>" name="c_id" maxlength="50" placeholder="Enter ID">
                    <?= form_error('c_id')?>
                  </div>
                </div>

                <div class="col-md-2">
                  <div class="form-group">
                    <label for="subscription">Subscription</label><span style="color: red"> *</span>
                    <input type="number" class="form-control" id="subscription" value="<?= set_value('subscription', '0.0') ?>" name="subscription" maxlength="5" placeholder="Enter Subscription">
                    <?= form_error('subscription')?>
                  </div>
                </div>

               <div class="col-md-2">
                <div class="form-group">
                  <label for="market_data">Market Data</label><span style="color: red"> *</span>
                  <input type="number" class="form-control" id="market_data" value="<?= set_value('market_data', '0.0') ?>" name="market_data" maxlength="100" placeholder="Enter Market Data ">
                  <?= form_error('market_data')?>
                </div>
              </div>


              <div class="col-md-2">
                <div class="form-group">
                  <label for="admin_fee">Admin Fee</label><span style="color: red"> *</span>
                  <input type="number" class="form-control" id="admin_fee" name="admin_fee" value="<?= set_value('admin_fee', '0.0') ?>" maxlength="5" placeholder="Enter Admin Fee">
                  <?= form_error('admin_fee')?>
                </div>
              </div>


              <div class="col-md-2">
                <div class="form-group">
                  <label for="others">Others</label><span style="color: red"> *</span>
                  <input type="number" class="form-control" id="others" name="others" value="<?= set_value('others', '0.0') ?>" maxlength="5" placeholder="Others">
                  <?= form_error('others')?>
                </div>
              </div>
              
              </div>

              <!--  Following Cost Are Per Trade Cost -->
              <h4><b>Following cost are per trade cost.</b></h4> 
            <div class="row">
                <div class="col-md-2">
                  <div class="form-group">
                    <label for="commision">Commision</label><span style="color: red"> *</span>
                    <input type="number" class="form-control" id="commision" value="<?= set_value('commision', '0.0') ?>" name="commision"  placeholder="Enter commision" min="0" max="10" step="0.001">
                    <?= form_error('commision')?>
                  </div>
                </div>

                <div class="col-md-2">
                  <div class="form-group">
                    <label for="clearingfee">Clearing Fee </label><span style="color: red"> *</span>
                    <input type="number" class="form-control" id="clearingfee" value="<?= set_value('clearingfee', '0.0') ?>" name="clearingfee"  placeholder="Enter Clearing Fee" min="0" max="10" step="0.001">
                    <?= form_error('clearingfee')?>
                  </div>
                </div>

               <div class="col-md-2">
                <div class="form-group">
                  <label for="exchangefee">Exchange Fee </label><span style="color: red"> *</span>
                  <input type="number" class="form-control" id="exchangefee" value="<?= set_value('exchangefee', '0.0') ?>" name="exchangefee" maxlength="6" placeholder="Enter Exchange Fee " min="0" max="10" step="0.001">
                  <?= form_error('exchangefee')?>
                </div>
              </div>


              <div class="col-md-2">
                <div class="form-group">
                  <label for="transationalfee">Transational Fee</label><span style="color: red"> *</span>
                  <input type="number" class="form-control" id="transationalfee" name="transationalfee" value="<?= set_value('transationalfee', '0.0') ?>" maxlength="6" placeholder="Enter Admin Fee" min="0" max="10" step="0.001">
                  <?= form_error('transationalfee')?>
                </div>
              </div>


              <div class="col-md-2">
                <div class="form-group">
                  <label for="nfa">NFA </label><span style="color: red"> *</span>
                  <input type="number" class="form-control" id="nfa" name="nfa" value="<?= set_value('nfa','0.0') ?>" maxlength="5" placeholder="NFA" min="0" max="10" step="0.001">
                  <?= form_error('nfa')?>
                </div>
              </div>

              <div class="col-md-2">
                <div class="form-group">
                  <label for="pertrade_other">Others </label><span style="color: red"> *</span>
                  <input type="number" class="form-control" id="pertrade_other" name="pertrade_other" value="<?= set_value('pertrade_other', '0.0') ?>" maxlength="5" placeholder="Others" min="0" max="10" step="0.001">
                  <?= form_error('pertrade_other')?>
                </div>
              </div>
              
              </div>   


              <div class="row">  
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="address">Address</label> <span style="color: red"> </span>
                    <input type="text" class="form-control" id="address" name="address" value="<?= set_value('address') ?>" maxlength="100" placeholder="Enter Clinet Address">
                     <?= form_error('address')?>
                  </div>
                </div>

                <div class="col-md-4">
                  <div class="form-group">
                    <label for="email">Email</label><span style="color: red"> </span>
                    <input type="text" class="form-control" id="email" name="email" maxlength="100" value="<?= set_value('email') ?>" placeholder="Enter Client email">
                    <?= form_error('email')?>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="mobile">Mobile</label><span style="color: red"> </span>
                    <input type="text" class="form-control" id="mobile" name="mobile" maxlength="10" value="<?= set_value('mobile') ?>" placeholder="Enter Valid 10 Digit mobile Number">
                    <?= form_error('mobile')?>
                  </div>
                </div>

               
                </div>  
                
                 
              </div>
              <!-- /.box-body -->

              <div class="box-footer text-right">
                <button type="submit" class="btn btn-primary ">Add Clinet</button>
              </div>
            </form>
          </div>
          <!-- /.box -->

          

        </div>
        <!--/.col (left) -->
        <!-- right column -->
        <!-- <div class="col-md-6"> -->
          <!-- Horizontal Form -->
          
          <!-- /.box -->
          <!-- general form elements disabled -->
           
          <!-- /.box -->
        <!-- </div> -->
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php $this->load->view('front/cms/footer') ?>

  <!-- Control Sidebar -->
  <?php $this->load->view('front/cms/rightsight') ?>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->
<?php $this->load->view('front/cms/js') ?>