<?php $this->load->view('front/cms/head')?>
 <!-- DataTables -->
  <link rel="stylesheet" href="<?=BASEURL?>assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">

<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">

  <?php $this->load->view('front/cms/header')?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('front/cms/sidebar')?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?=$title?>
        <!-- <small>Control panel</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><?=$pageheader?></li>
      </ol>
    </section>

    <!-- Main content -->
     <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title"><?=$pageheader?></h3>
            </div>
            <!-- /.box-header -->
              <!--  <div class="box-header">
              <h3 class="box-title">Data Table With Full Features</h3>
            </div> -->
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Mobile</th>
                    
                  <th>Roles</th>
                  <th>Create Date</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                  <?php if(count($users) > 0): foreach($users as $k => $v ):
                    //$rights = $this->mm->checkExistAccess($v->id);

                    ?>
                    <tr id="tr_<?=$v->id ?>" >
                      <td><?= $v->name ?></td>
                      <td><?= $v->email ?></td>
                      <td><?= $v->mobile ?></td>
                      <td><?= ($v->role_id == 1) ? 'USER' : 'ADMIN' ?></td>
                      <td><?=$v->create_at?></td>
                      <?php if($v->role_id =='1'): ?>
                      
                      <td><a href="<?=site_url("user-edit/$v->id")?>"data-toggle="tooltip" title="<?php echo $this->lang->line('edit') ?>" ><i class="fa fa-pencil"></i> </a>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                       <a href="javascript:void(0)" onclick="deleteRow('<?php echo $v->id ?>', 'user')"   data-toggle="tooltip" title="<?php echo $this->lang->line('delete') ?>"><i class="fa fa-trash"></i></a></td>
                       <?php else: ?>
                        <td></td>
                       <?php endif; ?>

                    </tr>
                  <?php endforeach;endif;?>
                  
                </tbody>
              </table>
            </div>

          

          </div>
          <!--/.col (left) -->
        </div> 
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php $this->load->view('front/cms/footer') ?>

  <!-- Control Sidebar -->
  <?php $this->load->view('front/cms/rightsight') ?>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->
<?php $this->load->view('front/cms/js') ?>

<!-- DataTables -->
<script src="<?=BASEURL?>assets/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?=BASEURL?>assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>

<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>