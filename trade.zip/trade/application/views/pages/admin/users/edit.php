<?php $this->load->view('front/cms/head')?>

<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">

  <?php $this->load->view('front/cms/header')?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('front/cms/sidebar')?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?=$title?>
        <!-- <small>Control panel</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><?=$pageheader?></li>
      </ol>
    </section>

    <!-- Main content -->
     <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title"><?=$pageheader?></h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <?php $this->load->view('pages/response')?>

            <form role="form" autocomplete="off" id="app_contract" method="post" action="<?=site_url('user-edit/'.$id)?>" enctype="multipart/form-data" >
              <input type="hidden" name="user_id" value="<?=$id?>">
              
              <div class="box-body">
                  
              <div class="row">  
                <div class="col-md-6">
                <div class="form-group">
                  <label for="name">Name</label> <span style="color: red"> *</span>
                  <input type="text" class="form-control" id="name" name="name" value="<?= set_value('name', $users->name) ?>" maxlength="100" placeholder="User Name">
                   <?= form_error('name')?>
                </div>
                </div>
                </div>
              <div class="row">
                <div class="col-md-6">
                <div class="form-group">
                  <label for="code1">Email</label><span style="color: red"> *</span>
                  <input type="text" class="form-control" id="email" name="email" maxlength="100" value="<?= set_value('email', $users->email) ?>" placeholder="Enter Contract Code">
                  <?= form_error('email')?>
                </div>
              </div>
              </div>

              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="mobbile">Mobile</label><span style="color: red"> *</span>
                    <input type="text" class="form-control" id="mobile" name="mobile" maxlength="10" value="<?= set_value('mobile', $users->mobile) ?>" placeholder="Enter Mobile">
                    <?= form_error('mobile')?>
                  </div>
                </div>
              </div>

               <!-- <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="password">Password</label><span style="color: red"> *</span>
                    <input type="text" class="form-control" id="password" name="password" value="<?= set_value('password') ?>"  maxlength="100" >
                    <?= form_error('password')?>
                  </div>
                </div>
              </div> -->


               <div class="row"> 
              

               <div class="col-md-3">
                <div class="form-group">
                  <label for="roles">Roles</label><span style="color: red"> *</span>
                  <select class="form-control" name="roles" >
                    <option value="0">--Select Roles--</option>
                    <?php foreach($roles as $key => $value):?>
                    <?php if($value->role_id == $users->role_id):?>
                      <option  value="<?=$value->role_id ?>" selected ><?=$value->role_name?></option>
                    <?php else:?>
                      <option  value="<?=$value->id ?>" <?= set_select('roles', $value->id) ?> ><?=$value->role_name?></option>
                    <?php endif;?>

                    <?php endforeach;?>
                  </select>
                   <?= form_error('roles')?>
                  
                </div>
                 </div>
              </div>   

                 
              </div>
              <!-- /.box-body -->

              <div class="box-footer text-right">
                <button type="submit" class="btn btn-primary ">Update</button>
              </div>
            </form>
          </div>
          <!-- /.box -->

          

        </div>
        <!--/.col (left) -->
        <!-- right column -->
        <!-- <div class="col-md-6"> -->
          <!-- Horizontal Form -->
          
          <!-- /.box -->
          <!-- general form elements disabled -->
           
          <!-- /.box -->
        <!-- </div> -->
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php $this->load->view('front/cms/footer') ?>

  <!-- Control Sidebar -->
  <?php $this->load->view('front/cms/rightsight') ?>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->
<?php $this->load->view('front/cms/js') ?>

