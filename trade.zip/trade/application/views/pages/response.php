<?php if(isset($this->session->success)){ ?>
  <div class="alert alert-success">
    <strong>Success! </strong> <?=$this->session->flashdata('success')?>
  </div>
<?php }

?>
<?php if(isset($this->session->fail)){ ?>
  <div class="alert alert-danger">
    <strong>Danger! </strong> <?=$this->session->flashdata('fail')?>
  </div>
<?php }
  
?>