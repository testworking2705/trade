<?php $this->load->view('front/cms/head')?>

<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">

  <?php $this->load->view('front/cms/header')?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('front/cms/sidebar')?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
     <section class="content">

      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title"><?= $form_title ?></h3>

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip"
                    title="Collapse">
              <i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
              <i class="fa fa-times"></i></button>
          </div>
        </div>
        <span id="responseMessage"> </span>
        <div class="box-body">
           <form role="form" id="tradeUpload" method="post" action="<?=site_url('upload')?>" enctype="multipart/form-data" >
              <div class="box-body">
                <div class="form-group">
                  <?php if( count($trades) > 0  && $trades != false ):
                  foreach($trades as $key => $v ): 
                    $checked = ($key == '0') ? 'checked' : '' ;
                    if($key == '0'){ ?>
                      <input type="hidden" id="tradeId" name="tradeId" value="<?=$v->id?>">
                    <?php }  ?>



                    <label>
                      
                      <input type="radio" id="<?=$v->id?>" name="trades" value="<?=$v->name?>"  <?=$checked?> > <?=$v->name ?> Trade
                    </label>
                    &nbsp;&nbsp;
                        
                  <?php endforeach;endif; ?>
                
                
                 
              </div>
                <!-- <div class="form-group">
                  <label for="exampleInputEmail1">Email address</label>
                  <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Password</label>
                  <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                </div> -->
                <div class="form-group">
                  <label for="tradefile">Select Trade File</label>
                  <input type="file" id="tradefile" name="tradefile" accept=".xls,.xlsx,.csv">

                  <!-- <p class="help-block" style="color: red">Please Select File Type CSV or Excel .</p> -->
                </div>
                <!-- <div class="checkbox">
                  <label>
                    <input type="checkbox"> Check me out
                  </label>
                </div> -->
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
        </div>
        <!-- /.box-body -->
        <!-- <div class="box-footer">
          Footer
        </div> -->
        <!-- /.box-footer-->
      </div>
      <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php $this->load->view('front/cms/footer') ?>

  <!-- Control Sidebar -->
  <?php $this->load->view('front/cms/rightsight') ?>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->
<?php $this->load->view('front/cms/js') ?>

<script type="text/javascript">
  $(function(){

    $("#tradeUpload").on('submit', function(e){
      e.preventDefault();
      console.log('CHECL OK');
        $.ajax({
          url: '<?php echo base_url(); ?>trades-upload',
          type: "POST",
          data: new FormData(this),
          dataType: 'json',
          contentType: false,
          cache: false,
          processData: false,
          success: function (data) {
            console.log('dataSUCCESS');
            console.log(data);
              if (data.error == true) {
                $("#responseMessage").text('Error : '+data.message).css('color', 'red');
                  //var message = "";
                  /*$.each(data.error, function (index, value) {
                      message += value;
                  });*/
                  //errorMsg(message);
              } else {
                $("#responseMessage").text('Success : '+data.message).css('color', 'green');
                  // successMsg(data.message);
                  // window.location.reload(true);
              }
          },
          error: function (error) {
              //  alert("Fail")
              console.log('error');
              console.log(error);
          }
      });

      //alert('OK YE S');
    });

  });
</script>

