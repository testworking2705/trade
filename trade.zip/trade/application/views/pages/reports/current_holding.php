<?php $this->load->view('front/cms/head')?>

<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">

  <?php $this->load->view('front/cms/header')?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('front/cms/sidebar')?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?=$title?>
        <!-- <small>Control panel</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><?=$pageheader?></li>
      </ol>
    </section>

    <!-- Main content -->
      <section class="content">
      <div class="row">
        <div class="col-xs-12">
         
          <!-- /.box -->

        <div class="box">
            <div class="box-header box-warning">
              <h3 class="box-title"><?=$pageheader?></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Sr.no</th>
                  <th>Contract</th>
                  <th>Client</th>
                  <th>Qty</th>
                  <th>Price</th>
                  <th>Fcm</th>
                  <th>Long Short</th>
                  <th>Date</th>
                </tr>
                </thead>
                <tbody>
                  <?php 
                    
                        if(count($holdings)> 0):
                          foreach ($holdings as $key => $v):
                           
                              ?>  
            
                              <tr >
                                <td><?=$key+1?></td>
                                <td><?=$v->contract?></td>
                                <td><?=$v->client_id?></td>
                                <td><?=$v->quantity?></td>
                                <td><?=$v->price?></td>
                                <td><?=$v->fcm?></td>
                                <td><?=$v->long_short?></td>
                                <td><?=$v->datetime?></td>
                                <!-- <td><?=date('d-m-y', strtotime($v->datetime))?></td> -->
                                
                              </tr>

                                     
                  <?php 
                              endforeach; 
                           endif;
                  ?>
                  <tr>
                    
                  
                  </tr>
                  
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php $this->load->view('front/cms/footer') ?>

  <!-- Control Sidebar -->
  <?php $this->load->view('front/cms/rightsight') ?>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->
<?php $this->load->view('front/cms/js') ?>

