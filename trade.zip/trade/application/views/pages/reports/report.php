<?php $this->load->view('front/cms/head')?>

<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">

  <?php $this->load->view('front/cms/header')?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('front/cms/sidebar')?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?=$title?>
        <!-- <small>Control panel</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><?=$pageheader?></li>
      </ol>
    </section>

    <!-- Main content -->
     <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title"><?=$pageheader?></h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <?php if(isset($this->session->success)){
              echo $this->session->flashdata('success') ;
            }

            ?>
            <?php if(isset($this->session->fail)){
              echo $this->session->flashdata('fail') ;
            }?>

            
            <div class="box-body">
              <!-- Date -->
              <span id="responseMessage">  </span>
              <form role="form" autocomplete="off" id="report_form" method="post" enctype="multipart/form-data" >
                
              
              <div class="col-md-3" >
                <div class="form-group">
                <label>Select Client </label>
                <select name="client" class="form-control" >
                  <option value="0">--Select--</option>
                  <?php if(count($clients) > 0): foreach ($clients as $k => $val): ?>
                    
                  <option value="<?=$val->id?>" <?= set_value('client', $val->id)?> ><?=$val->first_name?></option>
                  
                  <?php endforeach; endif; ?>
                </select>
                <!-- /.input group -->
              </div>
              </div>

              <div class="col-md-3" >
                <div class="form-group">
                <label>From </label>

                <div class="input-group date">
                  <div class="input-group-addon">
                    <i class="fa fa-calendar"></i>
                  </div>
                  <input type="text" class="form-control pull-right" name="from" id="from">
                </div>
                <!-- /.input group -->
              </div>
              </div>

              <div class="col-md-3" >
                <div class="form-group">
                  <label>To </label>

                  <div class="input-group date">
                    <div class="input-group-addon">
                      <i class="fa fa-calendar"></i>
                    </div>
                    <input type="text" class="form-control pull-right" name="to" id="to">
                  </div>
                  <!-- /.input group -->
                </div>
              </div>

              <div class="col-md-3" >
                <div class="form-group">
                  <label>&nbsp;</label>
                  <div class="input-group date">
                  <!-- <div class="input-group-addon"> -->
                    <!-- <i class="fa fa-calendar"></i> -->
                  <!-- </div> -->
                    <button type="submit" id="runcal" class="btn btn-block btn-warning pull-right" > Get Report </button> 
                </div>
              </div>
              </div>

            </form>  
              </div>
              <!-- /.form group -->

            <hr>
            <table  class="table table-bordered table-striped"  >
              <tr>
                <th>Sr.no</th>
                <th>Date</th>
                <th>Contract</th>
                <th>Client</th>
                <th>T.Contract </th>
                <th>C.Contract</th>
                <th>Comm</th>
                <th>Clea</th>
                <th>Exe</th>
                <th>Txn</th>
                <th>NFA</th>
                <!-- <th>Total fee</th> -->
                <th>GPL</th>
                <th>NPL</th>
                
                <!-- <th>Status</th> -->
              </tr>
              <tbody id="closecontract"></tbody>
            </table>

            <hr>
            <!-- <table class="table table-bordered table-striped" >
              <tr>
                <th>Sr.no</th>
                <th>contract</th>
                <th>client</th>
                <th>Qty</th>
                <th>Price</th>
                <th>Fcm</th>
                <th>Long Short</th>
                <th>Date</th>
                
              </tr>
              <tbody id="holdcontract"></tbody>
            </table> -->    

              

              

            
             
          </div>
          <!-- /.box -->

          

        </div>
         
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php $this->load->view('front/cms/footer') ?>

  <!-- Control Sidebar -->
  <?php $this->load->view('front/cms/rightsight') ?>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->
<?php $this->load->view('front/cms/js') ?>

<script type="text/javascript">

 


  $(function() {
    // body...

    // alert('Ok fine');
    $("#report_form").on('submit', function(e){
      e.preventDefault();
      //console.log($( this ).serializeArray());
      var request = $.ajax({
        url: '<?=site_url('report/getReportData')?>',
        method: "POST",
        data: $( this ).serializeArray(),
        dataType: "json"
      });
       
      request.done(function( msg ) {
        console.log('DONE ');
        console.log(msg);
        if(msg.error == false){
          $("#responseMessage").text(msg.message).css('color', 'green');
        }
        else if(msg.error == true ){
          $("#responseMessage").text(msg.message).css('color', 'red');return false ;
        }

        if(msg.data.length > 0){
          var data = msg.data ; 
          var closecontract ='';sr=1;
          //for (var i = 0; i < closecontracts.length; i++) {
            console.log(" YES ");
            console.log(data);  // <td>'+value.total_fee+' </td>
            $.each(data, function (index, value) {
              closecontract += '<tr><td>'+ sr++ +'</td> <td>'+value.trade_date+'</td>  <td>'+value.contract_name+'</td> <td>'+value.client_id+' </td> <td>'+value.total_contract+' </td> <td>'+value.close_contract+' </td> <td>'+value.total_comm+' </td> <td>'+value.total_clear+' </td> <td>'+value.total_exe+' </td> <td>'+value.total_txn+' </td> <td>'+value.total_nfa+' </td>  <td>'+(value.total_gpl > 0 ? value.total_gpl : value.total_gpl.replace("-", "")+'DR'  )+' </td> <td>'+(value.total_npl > 0 ? value.total_npl : value.total_npl.replace("-", "")+'DR' )+' </td>  </tr>' ;
                //message += value;
            });
            $("#closecontract").html(closecontract);

          //}
          
        }
       //if(msg.hold.length > 0){
           // console.log(msg.hold);
            //var holdcontract ='';sr=1;

           /* $.each(msg.hold, function (index, value) {
              holdcontract += '<tr><td>'+ sr++ +'</td>  <td>'+value.contract+'</td> <td>'+value.client_id+' </td> <td>'+value.quantity+' </td> <td>'+value.price+' </td> <td>'+value.fcm+' </td> <td>'+value.long_short+' </td> <td>'+value.date+' </td> </tr>' ;
                //message += value;
            });
            $("#holdcontract").html(holdcontract);*/
         // } 
        
        

      });
       
      request.fail(function( jqXHR, textStatus ) {
        alert( "Request failed: " + textStatus );
      });  
     
  
      //alert('OK');
    }); //!!!.... calculation  Close
  }); //!!!.... Funcation Close 
</script>