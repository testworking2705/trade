<?php $this->load->view('front/cms/head')?>

<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">

  <?php $this->load->view('front/cms/header')?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('front/cms/sidebar')?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?=$title?>
        <!-- <small>Control panel</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><?=$pageheader?></li>
      </ol>
    </section>

    <!-- Main content -->
     <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title"><?=$pageheader?></h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <?php if(isset($this->session->success)){
              echo $this->session->flashdata('success') ;
            }

            ?>
            <?php if(isset($this->session->fail)){
              echo $this->session->flashdata('fail') ;
            }?>

            
            <div class="box-body">
              <!-- Date -->
              <span id="responseMessage">  </span>
              <form role="form" autocomplete="off" id="report_form" method="post" enctype="multipart/form-data" >
                
              
              <div class="col-md-3" >
                <div class="form-group">
                <label>Select Client </label>
                <select name="client" class="form-control" >
                  <option value="0">--Select--</option>
                  <?php if(count($clients) > 0): foreach ($clients as $k => $val): ?>
                    
                  <option value="<?=$val->first_name?>" <?= set_value('client', $val->first_name)?> ><?=$val->first_name?></option>
                  
                  <?php endforeach; endif; ?>
                </select>
                <!-- /.input group -->
              </div>
              </div>

              <div class="col-md-3" >
                <div class="form-group">
                <label>From </label>

                <div class="input-group date">
                  <div class="input-group-addon">
                    <i class="fa fa-calendar"></i>
                  </div>
                  <input type="text" class="form-control pull-right" name="from" id="from">
                </div>
                <!-- /.input group -->
              </div>
              </div>

              <div class="col-md-3" >
                <div class="form-group">
                  <label>To </label>

                  <div class="input-group date">
                    <div class="input-group-addon">
                      <i class="fa fa-calendar"></i>
                    </div>
                    <input type="text" class="form-control pull-right" name="to" id="to">
                  </div>
                  <!-- /.input group -->
                </div>
              </div>

              <div class="col-md-3" >
                <div class="form-group">
                  <label>&nbsp;</label>
                  <div class="input-group date">
                  <!-- <div class="input-group-addon"> -->
                    <!-- <i class="fa fa-calendar"></i> -->
                  <!-- </div> -->
                    <button type="submit" id="runcal" class="btn btn-block btn-warning pull-right" > Get Report </button> 
                </div>
              </div>
              </div>

            </form>  
              </div>
              <!-- /.form group -->

            <hr>
            <table  class="table table-bordered table-striped"  >
              <thead id="thead"></thead>
              <tbody id="contract"></tbody>
            </table>

            <hr>        
          </div>
          <!-- /.box -->

          

        </div>
         
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php $this->load->view('front/cms/footer') ?>

  <!-- Control Sidebar -->
  <?php $this->load->view('front/cms/rightsight') ?>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->
<?php $this->load->view('front/cms/js') ?>

<script type="text/javascript">





  $(function() {
    // body...

    // alert('Ok fine');
    $("#report_form").on('submit', function(e){
      e.preventDefault();
      //console.log($( this ).serializeArray());
      var request = $.ajax({
        url: '<?=site_url('report/contractMonthWise')?>',
        method: "POST",
        data: $( this ).serializeArray(),
        dataType: "json"
      });
       
      request.done(function( msg ) {
        console.log('DONE ');
        console.log(msg);
        var dates, contracts, data, d, ddarr, thead ,tbody ;
        try{
          if(msg.error == false){
            //alert("OK");
            //dates = msg.date;
            //contracts = msg.contract;
            data = msg.data;
            ddarr = msg.ddarr;
            console.log(data);
            thead +='<tr><td>#</td>';
            for(i in ddarr){
              //console.log(ddarr[i]);
              thead +='<td>'+ddarr[i].substr(5,5)+'</td>' ;
            }
            thead +='</tr>';
            $("#thead").html(thead); 


            //console.log(thead);
              
             console.log('ct>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>');
              
            var blankspace = false, tbody='' ;

         /* for (var i = 0; i < data.length; i++) {
            // data[i];
            console.log('dsfsdfsdfs');
            console.log(data[i]);
          }*/
            
            //for(i in contracts){
              //for(l in ddarr){
                for(j in data){
                    console.log('indexc ' + j);
                  var ct = data[j] ;
                  //console.log(data[j]);
                  tbody +='<tr><td>'+j+'</td>';
                  if(ct.length > 0){                    
                    console.log(ct);
                    for(d in ddarr){
                      for(k in ct){
                        if(ct[k]['date'] == ddarr[d]){
                          tbody += '<td>'+ct[k]['ct']+'</td>' ;
                          blankspace = false;
                          break ;
                        }
                        else{
                          blankspace = true ;
                          //
                        }
                      }
                      if(blankspace){
                        tbody += '<td>0</td>' ;
                      }
                    } // ct for loop 
                  }
                  tbody +='</tr>';
                }
            

                
                //tbody +=tbody;
                console.log('tbody');
                           console.log(tbody);
              //}
            //}
            console.log('final me agaya');
            $("#contract").html(tbody);
          }

          
        }catch(err){
          // alert(err);
          console.log('EXCEPTION ');
          console.log(err);
        }


        /*if(msg.error == false){
          $("#responseMessage").text(msg.message).css('color', 'green');
        }
        else if(msg.error == true ){
          $("#responseMessage").text(msg.message).css('color', 'red');return false ;
        }*/

        /*if(msg.data.length > 0){
          var data = msg.data ; 
          var closecontract ='';sr=1;
          //for (var i = 0; i < closecontracts.length; i++) {
            console.log(" YES ");
            console.log(data);  // <td>'+value.total_fee+' </td>
            $.each(data, function (index, value) {
              closecontract += '<tr><td>'+ sr++ +'</td> <td>'+value.trade_date+'</td>  <td>'+value.contract_name+'</td> <td>'+value.client_id+' </td> <td>'+value.total_contract+' </td> <td>'+value.close_contract+' </td> <td>'+value.total_comm+' </td> <td>'+value.total_clear+' </td> <td>'+value.total_exe+' </td> <td>'+value.total_txn+' </td> <td>'+value.total_nfa+' </td>  <td>'+(value.total_gpl > 0 ? value.total_gpl : value.total_gpl.replace("-", "")+'DR'  )+' </td> <td>'+(value.total_npl > 0 ? value.total_npl : value.total_npl.replace("-", "")+'DR' )+' </td>  </tr>' ;
                //message += value;
            });
            $("#closecontract").html(closecontract);

          //}
          
        }*/
       //if(msg.hold.length > 0){
           // console.log(msg.hold);
            //var holdcontract ='';sr=1;

           /* $.each(msg.hold, function (index, value) {
              holdcontract += '<tr><td>'+ sr++ +'</td>  <td>'+value.contract+'</td> <td>'+value.client_id+' </td> <td>'+value.quantity+' </td> <td>'+value.price+' </td> <td>'+value.fcm+' </td> <td>'+value.long_short+' </td> <td>'+value.date+' </td> </tr>' ;
                //message += value;
            });
            $("#holdcontract").html(holdcontract);*/
         // } 
        
        

      });
       
      request.fail(function( jqXHR, textStatus ) {
        alert( "Request failed: " + textStatus );
      });  
     
  
      //alert('OK');
    }); //!!!.... calculation  Close
  }); //!!!.... Funcation Close 
</script>