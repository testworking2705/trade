<?php $this->load->view('front/cms/head')?>

<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">

  <?php $this->load->view('front/cms/header')?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('front/cms/sidebar')?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?=count($clients)?></h3>

              <p>Clients</p>
            </div>
            <div class="icon">
              <i class="ion ion-bag"></i>
            </div>
             
            <a href="javascript:void(0)" onclick="show_records('<?php echo site_url('dashboard/clientList'); ?>','client')" class="small-box-footer ">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3><?=count($companies)?><!-- <sup style="font-size: 20px">%</sup> --></h3>

              <p>Company</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <a href="javascript:void(0)" onclick="show_records('<?php echo site_url('dashboard/companyList'); ?>','company')" class="small-box-footer ">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3><?=count($contracts)?></h3>

              <p>Contract</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
           <a href="javascript:void(0)" onclick="show_records('<?php echo site_url('dashboard/contractList'); ?>','contract')" class="small-box-footer ">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3><?=count($report)?></h3>

              <p>Reports</p>
            </div>
            <div class="icon">
              <i class="ion ion-pie-graph"></i>
            </div>
            <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
      </div>
      <div class="row">
      <div class="col-md-12">
        <div class="box box-warning">
            <div class="box-header ">
              <h3 class="box-title">Data Table With Full Features</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body ">
              <table id="example1" class="table table-bordered table-striped">
                <thead id="thead">                 
                </thead>
                <tbody id="tbody">
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>
      </div>
      <!-- /.row -->
      <!-- Main row -->
       
      <!-- /.row (main row) -->

    </section>

    

    
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php $this->load->view('front/cms/footer') ?>

  <!-- Control Sidebar -->
  <?php $this->load->view('front/cms/rightsight') ?>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>

<!-- 
  <th>Subscription</th>
  <th>Market Data</th>
  <th>Admin Fee</th>
  <th>Other</th> -->
 
  
  <!-- <th>Address</th>
  <th>Email</th>
  <th>Mobile</th> -->



<!-- ./wrapper -->
<?php $this->load->view('front/cms/js') ?>
<script type="text/javascript">
  function show_records(url, name) {
    //alert(url);
    //if (confirm(<?php echo "'" . $this->lang->line('delete_conform') . "'"; ?>)) {
        $.ajax({
            url: url,
            success: function (res) {
              console.log(res);
              setHeaderData(name, res);
                //successMsg(Msg);
                //window.location.reload(true);
            }
        })
    //}
  }

  function setHeaderData(name, dataJson){
    var dataJson = JSON.parse(dataJson);
    var data ;
    if(name =='client'){
      var headData ='<tr><th>#</th><th>Client ID</th><th>name</th><th>Associated</th><th>ID</th> <th>Comm.</th><th>Clear.</th>  <th>Exch.</th>  <th>Tran.</th>  <th>NFA </th>  <th>Others</th> </tr>' ;
      $.each(dataJson, function(key, v){
        data += '<tr><td>#</td><td>'+v.client_id+'</td><td>'+v.first_name+'</td><td>'+v.company_associated_with+'</td><td>'+v.cid+'</td> <td>'+v.commission+'</td><td>'+v.exchange_fee+'</td>  <td>'+v.exchange_fee+'</td>  <td>'+v.tradetinal+'</td>  <td>'+v.nfa+' </td>  <td>'+v.others2+'</td> </tr>';
      });

      $("#thead").html(headData);
      $("#tbody").html(data);

    }
    else if(name =='company'){
      var headData ='<tr><th>#</th><th>Client ID</th><th>name</th><th>Associated</th><th>ID</th> <th>Comm.</th><th>Clear.</th>  <th>Exch.</th>  <th>Tran.</th>  <th>NFA </th>  <th>Others</th><th>Date</th> <th>Action</th></tr>' ;

     $.each(dataJson, function(key, v){
         data += '<tr><td>#</td><td>'+v.client_id+'</td><td>'+v.first_name+'</td><td>'+v.company_associated_with+'</td><td>'+v.cid+'</td> <td>'+v.commission+'</td><td>'+v.exchange_fee+'</td>  <td>'+v.exchange_fee+'</td>  <td>'+v.tradetinal+'</td>  <td>'+v.nfa+' </td>  <td>'+v.others2+'</td> </tr>';
        });

      $("#thead").html(headData);
      $("#tbody").html(data);
    }
    else if(name =='contract'){
      var headData ='<tr><th>#</th><th>Contrcat Name</th><th>Code</th><th>Tick Size</th><th>Tick Value</th> <th>Tick Value.</th><th>Contract Cycle.</th>  <th>Currency</th>  <th>First Notic</th>  <th>Expiry </th>  <th>Margin</th> </tr>' ;
      $.each(dataJson, function(key, v){
         data += '<tr><td>#</td> <td>'+v.contract_name+'</td><td>'+v.code+'</td><td>'+v.tick_size+'</td><td>'+v.tick_value+'</td> <td>'+v.contract_cycle+'</td><td>'+v.currency+'</td>  <td>'+v.first_notice+'</td>  <td>'+v.expiry+'</td>  <td>'+v.contract_margin+' </td>  </tr>';
      });

      $("#thead").html(headData);
      $("#tbody").html(data); 
    }

  }


</script>

