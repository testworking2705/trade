<?php
class UploadModel extends CI_Model{

	public function insert($data, $tableName='')
	{
		// return  $this->db->insert_batch('tbl_info', $data);
		$query = "INSERT INTO mytable (title, name, date) VALUES ".$data ;
		return $this->db->query($query);
				
	}


	public function columnsMaster($id)
	{				$this->db->select('column_name, names');
		$query = $this->db->get_where('trades_columns_master', array('trade_id' => $id ));
		return $query->result();
	}
}
?>