<?php
class ClientModel extends CI_Model{

	public function create($data)
	{
		$this->db->insert('client_mst', $data);
		return $this->db->affected_rows();
	}

	public function update($data='', $id)
	{
		$this->db->where('id', $id);
		$this->db->update('client_mst', $data);
		return  $this->db->affected_rows();
	}

	public function delete($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('client_mst');
		return  $this->db->affected_rows();
	}

	public function getClientById($id='')
	{		
		$result = $this->db->get_where('client_mst', array('id'=>	$id));	
		if($result->num_rows() > 0){
			return $result->row() ;
		}
		else{
			return false ;
		}
	}



	public function getClients($id = "")
	{
		if(!empty($id)){
			$result = $this->db->get_where('client_mst', array('client_id'=>	$id));	
		}
		else{
			$result = $this->db->get('client_mst');
		}
		if($result->num_rows() > 0){
			return $result->result() ;
		}
		else{
			return false ;
		}	
		
	}
		

	public function getDatafromDatatable($name, $date, $contract ='')
	{	
		// $arr = array('name'=>	'STC'); 
		//WHERE datetime = '02-18-20'
		if(!empty($name) && !empty($date) && !empty($contract) ){
			$arr = array('today_Status'=>	'1', 'name'=>	$name, 'datetime >=' => $date, 'datetime <=' => $date, 'contract'=> $contract ); 
		}
		else if(!empty($name)  && !empty($date) ){
			$arr = array('today_Status'=>	'1', 'name'=>	$name, 'datetime >=' => $date, 'datetime <=' => $date); 
		} 
		else{
			// $arr = array('today_Status'=>	'1', 'name'=>	'Sinia Global / Krati Seth'); 	
			// $arr = array('today_Status'=>	'1', 'datetime' => '02-18-20'); //, 'fcm'=>	'XYZ' 	
			// $arr = array('today_Status'=>	'1'); //, 'fcm'=>	'XYZ'
			$arr = array('today_Status'=>	'1', 'name'=>	$name, 'fcm'=>	$broker, 'datetime >=' => $date, 'datetime <=' => $date); 	
		}

		$this->db->select('id, name, long_short, contract, price AS total_price, qunatity AS qty, fcm, work_status, datetime');
		$this->db->order_by('price', 'ASC');
		$result = $this->db->get_where('data_table', $arr);
		//echo $this->db->last_query();

		if($result->num_rows() > 0){
			//echo "OK FROM MODEL";
			 return $result->result_array() ;
		}
		else{
			//echo "NOT OK FROM MODEL";
			return false ;
		}
	}

	public function getDataCompanyWise($broker, $date)
	{	
	
		// $arr = array('today_Status'=>	'1', 'fcm'=>	$cp_name, 'name'=>	'Sinia Global / Krati Seth'); 
		$arr = array('today_Status'=>	'1', 'fcm'=>$broker , 'datetime >=' => $date, 'datetime <=' => $date); 
		$this->db->select('id, name, long_short, contract, price AS total_price, qunatity AS qty, fcm, work_status, datetime');
		$this->db->order_by('price', 'ASC');
		$result = $this->db->get_where('data_table', $arr);

		if($result->num_rows() > 0){
			 return $result->result_array() ;
		}
		else{
			return array() ;
		}
	}

	public function ClientList($value='')
	{
		$this->db->select('name');
		$this->db->distinct();
		$this->db->order_by('price', 'ASC');
		$query = $this->db->get('data_table');
		// echo $this->db->last_query();
		return $query->result_array();

	}

	/*
		Get date List Of New Uploded Data 

	*/

	public function getNewDateList($from='', $to='', $column_name, $broker='')
	{
		if(!empty($broker)){
			$arr = array('today_status' => '1', 'datetime >=' => $from, 'datetime <=' => $to, 'fcm' => trim($broker));
		}
		else{
			$arr = array('today_status' => '1', 'datetime >=' => $from, 'datetime <=' => $to);
		}

		$this->db->select($column_name);
		$this->db->distinct();
		$query = $this->db->get_where('data_table', $arr);
		//echo $this->db->last_query();
		if($query->num_rows()> 0){
			return $query->result();
		}
		else{
			return array();
		}
	}

	/*
		Get data List Of New Uploded Data between date range. 

	*/
	public function getNewDataListOfDateRange($date)
	{	
		if(!empty($date))
			$arr = array('today_status' => '1', 'datetime >=' => $date, 'datetime <=' => $date); 
		else
			$arr = array('today_Status'=>	'1'); //, 'fcm'=>	'XYZ' 	
		 
		$this->db->select('id, name, long_short, contract, price AS total_price, qunatity AS qty, fcm, work_status, datetime');
		$this->db->order_by('price', 'ASC');
		$result = $this->db->get_where('data_table', $arr);
		//echo $this->db->last_query();
		if($result->num_rows() > 0){
			return $result->result_array() ;
		}
		else{
			return array() ;
		}
	}


}
		


?>