<?php
class MasterModel extends CI_Model{

	public function trades($id='')
	{
		if(!empty($id)){
			$result = $this->db->get_where('trades_mst', array('status'=>	1, 'trade_id' => $id));
			if($result->num_rows() > 0){
				 return $result->row() ;
			}
			else{
				return array() ;
			}
		}
		else{
			$result = $this->db->get_where('trades_mst', array('status'=>	1));
			if($result->num_rows() > 0){
				 return $result->result() ;
			}
			else{
				return false ;
			}
		}



	}


	public function currency()
	{
		$result = $this->db->get_where('currency_mst', array('status'=>	1));
		if($result->num_rows() > 0){
			//echo $this->db->last_query();
			 return $result->result() ;
		}
		else{
			return false ;
		}
		
	}

	

	public function roles($id='')
	{
	 
		$result = $this->db->get_where('roles');
		if($result->num_rows() > 0)
			 return $result->result() ;
		else
			return false ;			
		 
	}


	/*public function getAccess($id='')
	{	
		 
		$result = $this->db->get_where('access');
		if($result->num_rows() > 0)
			 return $result->result() ;
		else
			return array() ;	
	}
		
					


	public function checkExistAccess($id='')
	{	
		$result = $this->db->get_where('set_access', array('user_id' => $id));
		if($result->num_rows() > 0)
			 return $result->row() ;
		else
			return array() ;
	}

	public function checkExistAccess($id='')
	{	
		$this->db->select('id, access_name ');
		$result = $this->db->get_where('set_access', array('user_id' => $id));
		if($result->num_rows() > 0)
			 return $result->row() ;
		else
			return array() ;
	}
		 
					



	public function addUserRights($data)
	{
		$this->db->insert('set_access', $data);
		return $this->db->affected_rows();				
	}

	public function updateUserRights($id='', $data)
	{
		$this->db->where('user_id', $id);
		$this->db->update('set_access', $data);
		return $this->db->affected_rows();				
	}*/
		 

	public function roleById($id='')
	{
		$this->db->select('role_id');
		$result = $this->db->get_where('roles', array('id' => $id));
		if($result->num_rows() > 0)
			 return $result->row()->role_id ;
		else
			return false ;
		
	}


	public function closeingPrice($from,$to)
	{
		$this->db->order_by('close_date', 'ASC');
		$result = $this->db->get_where('closing_price', array('close_date >=' => $from , 'close_date <=' => $to));
		//echo $this->db->last_query();
		if($result->num_rows() > 0){
			//echo $this->db->last_query();
			 return $result->result() ;
		}
		else{
			return false ;
		}
		
	}

	public function contractListDateWise( $from = "", $to = "", $id = "")
	{
		$this->db->order_by('datetime', 'ASC');
		if(!empty($id)){
			$arr = array('id'=>	$id, 'datetime >=' => $from , 'datetime <=' => $to) ;
			$result = $this->db->get_where('data_table', $arr);
			if($result->num_rows() > 0)
				return $result->row() ;
			else
				return array() ;	
		}
		else{
			$arr = array('datetime >=' => $from , 'datetime <=' => $to) ;
			$this->db->select('contract');
			$this->db->distinct('contract');
			$result = $this->db->get_where('data_table', $arr);
			//echo $this->db->last_query();
			if($result->num_rows() > 0)
				return $result->result() ;
			else
				return array() ;
		}
			
	}

	
		
		

	 

	##########################################################################
	###############   Out Come Data store for Success.	
	##########################################################################
 
}
?>