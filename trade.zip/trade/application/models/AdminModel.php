<?php
class AdminModel extends CI_Model{

	public function trades()
	{
		$result = $this->db->get_where('trades_mst', array('status'=>	1));
		if($result->num_rows() > 0){
			 return $result->result() ;
		}
		else{
			return false ;
		}
		
	}

	public function getDatafromDatatable()
	{	
		$arr = array('name'=>	'STC'); 
		$this->db->select('id, name, long_short, contract, SUM(price) AS total_price, SUM(qunatity) AS qty, fcm');
		$this->db->group_by('name');
		$this->db->group_by('contract');
		$this->db->group_by('long_short');
		$this->db->order_by('id', 'ASC');
		$result = $this->db->get_where('data_table', $arr);
		//echo $this->db->last_query();

		if($result->num_rows() > 0){
			return $result->result() ;
		}
		else{
			return false ;
		}
		
	}

	public function roleNameByRoleID($roleID)
	{
		$query = $this->db->get_where('roles' , array('role_id'=>$roleID ));
		return $query->row()->role_name;
		// print_r($query->row());
		// print_r($this->db->last_query());
	}





	##########################################################################
	###############   Out Come Data store for Success.	
	##########################################################################

	public function SaveOutput($data='')
	{
		return $this->db->insert('output_data', $data);
	}

	public function SaveOutputHold($data='')
	{
		return $this->db->insert('hold_contract', $data);
	}

	public function updateStatus($id, $data)
	{
		$this->db->where('name', $id);
		$this->db->where('today_Status', 1);
		$this->db->update('data_table',$data);
		//echo $this->db->last_query();
	}

}
?>