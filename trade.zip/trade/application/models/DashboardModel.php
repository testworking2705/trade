<?php
class DashboardModel extends CI_Model{

	public function login($user, $pass)
	{
		$res = $this->db->get_where('users', array('email'=> $user, 'password' => $pass ));
		//echo $this->db->last_query();exit();
		if($res->num_rows() > 0){
			 return true ;
		}
		else{
			return false ;
		}
		//$res->result();
	}

	
}
?>