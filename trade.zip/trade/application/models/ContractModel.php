<?php
class ContractModel extends CI_Model{

	public function getContracts($id = "")
	{
		$this->db->order_by('code', 'ASC');
		if(!empty($id)){
			$result = $this->db->get_where('contract_mst', array('id'=>	$id));
			if($result->num_rows() > 0)
				return $result->row() ;
			else
				return array() ;	
		}
		else{
			$result = $this->db->get('contract_mst');
			if($result->num_rows() > 0)
				return $result->result() ;
			else
				return array() ;
		}
			
	}

	



	public function create($data='')
	{
		$this->db->insert('contract_mst', $data);
		///echo $this->db->last_query();
		return  $this->db->insert_id();
	}

	public function update($data='', $id)
	{
		$this->db->where('id', $id);
		$this->db->update('contract_mst', $data);
		///echo $this->db->last_query();
		return  $this->db->affected_rows();
	}

	public function delete($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('contract_mst');
		return  $this->db->affected_rows();
	}
	
	public function updateContarctStatus($client, $date, $contract, $fcm)
	{
		$this->db->where('name', $client);
		$this->db->where('contract', $contract);
		$this->db->where('datetime', $date);
		$this->db->where('fcm', $fcm);
		$this->db->update('data_table',array('today_Status' => 0 ));
		//echo $this->db->last_query();
	}



	public function activeHolding($value='')
	{
		$arr = array('hold_status' => 1);
		$query = $this->db->get_where('hold_contract', $arr);
		if($query->num_rows() > 0)
			return $query->result();
		else
			return array();


	}
		

	
}
?>