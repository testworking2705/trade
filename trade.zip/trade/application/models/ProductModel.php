<?php
class ProductModel extends CI_Model{

	
}
?>