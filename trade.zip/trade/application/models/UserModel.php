<?php
class UserModel extends CI_Model{

	public function getUser($id = "")
	{
		//$this->db->order_by('code', 'ASC');
		if(!empty($id)){
			$result = $this->db->get_where('users', array('id'=>$id));
			if($result->num_rows() > 0)
				return $result->row() ;
			else
				return array() ;	
		}
		else{
			$result = $this->db->get_where('users');
			if($result->num_rows() > 0)
				return $result->result() ;
			else
				return array() ;
		}
			
	}

	public function store($data='')
	{
		$this->db->insert('users', $data);
		return  $this->db->insert_id();
	}

	public function update($data='', $id)
	{
		$this->db->where('id', $id);
		$this->db->update('users', $data);
		///echo $this->db->last_query();
		return  $this->db->affected_rows();
	}

	public function delete($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('users');
		return  $this->db->affected_rows();
	}

	public function updateContarctStatus($client, $date, $contract, $fcm)
	{
		$this->db->where('name', $client);
		$this->db->where('contract', $contract);
		$this->db->where('datetime', $date);
		$this->db->where('fcm', $fcm);
		$this->db->update('data_table',array('today_Status' => 0 ));
		//echo $this->db->last_query();
	}



	public function activeHolding($value='')
	{
		$arr = array('hold_status' => 1);
		$query = $this->db->get_where('hold_contract', $arr);
		if($query->num_rows() > 0)
			return $query->result();
		else
			return array();
	}


		

	
}
?>