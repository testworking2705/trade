<?php
class ReportModel extends CI_Model{
		

	public function changeDateFormat($date)
	{
		return date('m-d-y', strtotime($date));
	}


	public function contractWiseReport($from, $to , $client_id='')
	{
		//$from = $this->changeDateFormat($from);
		//$to = $this->changeDateFormat($to);
		if(empty($client_id)){
			$arr = array('trade_date >=' => $from, 'trade_date <=' => $to  );
		}
		else{
			$arr = array('trade_date >=' => $from, 'trade_date <=' => $to , 'client_id' => $client_id );
		}
		$query = $this->db->get_where('contract_wise_dete_report', $arr);
		//echo $this->db->last_query();
		if($query->num_rows()> 0)
			return $query->result();
		else
			return false ;
	}

	// 21-03-2020
	public function contractMonthWise($from, $to , $client_id='')
	{
		//$from = $this->changeDateFormat($from);
		//$to = $this->changeDateFormat($to);
		//SELECT  contract, sum(qunatity) As contract_count, datetime FROM `data_table` WHERE name ='Sinia Global / Krati Seth' AND datetime >='2020-02-01' AND datetime <='2020-02-31'  GROUP BY contract ORDER BY datetime ASC
		if(empty($client_id)){
			$arr = array('datetime >=' => $from, 'datetime <=' => $to , 'name' => $client_id  );
		}
		else{
			$arr = array('datetime >=' => $from, 'datetime <=' => $to , 'name' => $client_id );
		}
		$this->db->select('contract, sum(qunatity) As contract_count, datetime');
		$this->db->group_by('contract');
		$this->db->group_by('datetime');
		$this->db->order_by('datetime', 'ASC');
		$query = $this->db->get_where('data_table', $arr);
		//echo $this->db->last_query();
		if($query->num_rows()> 0)
			return $query->result_array();
		else
			return false ;
	}

	public function tradeWiseDetils($from, $to , $client_id='')
	{
		$from = $this->changeDateFormat($from);
		$to = $this->changeDateFormat($to);
		if(empty($client_id)){
			$arr = array('trade_date >=' => $from, 'trade_date <=' => $to  );
		}
		else{
			$arr = array('trade_date >=' => $from, 'trade_date <=' => $to , 'client_id' => $client_id );
		}
		$query = $this->db->get_where('output_data', $arr);
		//echo $this->db->last_query();
		if($query->num_rows()> 0)
			return $query->result();
		else
			return false ;
	}
		




	public function closeTrade($name='')
	{
		//$this->db->select('o.id, o.client_id, o.contarct_id, o.product_name, o.buy_price, o.sale_price, o.buy_count, o.sale_count, o.buy_sale_diff, o.gpl, o.npl, o.brokerage, o.tradetinal, o.exchange, o.clearing, o.nfa ,o.fcm');
		$this->db->select('o.id, o.client_id, o.contarct_id, o.product_name, o.buy_price,o.sale_price, o.buy_count,o.sale_count, o.gpl, o.npl, o.brokerage, o.tradetinal, o.exchange, o.clearing, o.nfa ,o.fcm,o.trade_type');
		$this->db->from('output_data AS o');
		//$this->db->join('hold_contract AS h', 'o.client_id = h.client_id', "left");
		$this->db->where('o.client_id', $name);
		$query = $this->db->get();
		return $query->result_array();


	}

	public function holdTrade($name='')
	{
		//$this->db->select('o.id, o.client_id, o.contarct_id, o.product_name, o.buy_price, o.sale_price, o.buy_count, o.sale_count, o.buy_sale_diff, o.gpl, o.npl, o.brokerage, o.tradetinal, o.exchange, o.clearing, o.nfa,o.fcm');
		$this->db->select('o.id, o.client_id, o.contarct_id, o.product_name, o.buy_price,o.sale_price, o.buy_count,o.sale_count, o.gpl, o.npl, o.brokerage, o.tradetinal, o.exchange, o.clearing, o.nfa ,o.fcm,o.trade_type');
		$this->db->from('hold_contract AS o');
		//$this->db->join('hold_contract AS h', 'o.client_id = h.client_id', "left");
		$this->db->where('o.client_id', $name);
		$query = $this->db->get();
		return $query->result_array();


	}
}
		/*$this->db->select('patients.*,opd_details.appointment_date,opd_details.case_type,opd_details.case_type,staff.name,staff.surname
                  ')->from('patients');
        $this->db->join('opd_details', 'patients.id = opd_details.patient_id', "inner");
        $this->db->join('staff', 'staff.id = opd_details.cons_doctor', "inner");
        $this->db->where('patients.is_active', 'yes');
        $this->db->where('opd_details.appointment_date < ', $last_date);
        $this->db->group_start();
        $this->db->like('patients.patient_name', $searchterm);
        $this->db->or_like('patients.guardian_name', $searchterm);
        $this->db->group_end();
        $this->db->order_by('patients.id', 'desc');
        $this->db->group_by('opd_details.patient_id');
        $query = $this->db->get();*/


?>


