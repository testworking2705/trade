<?php
class CompanyModel extends CI_Model{
	
	/*
	*	Company list or with company id base
	*/
	public function getList($id = "")
	{
		if(!empty($id)){
			$result = $this->db->get_where('company_mst', array('id'=>	$id));
			if($result->num_rows() > 0){
				echo $this->db->last_query();
				return $result->row() ;
			}
		}
		else{
			$result = $this->db->get('company_mst');
			if($result->num_rows() > 0){
				return $result->result() ;
			}
		}
		return array() ;
	}

	public function create($data)
	{
		$this->db->insert('company_mst', $data);
		return $this->db->affected_rows();
	}

	public function update($data='', $id)
	{
		$this->db->where('id', $id);
		$this->db->update('company_mst', $data);
		return  $this->db->affected_rows();
	}

	public function delete($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('company_mst');
		return  $this->db->affected_rows();
	}
}
		


?>